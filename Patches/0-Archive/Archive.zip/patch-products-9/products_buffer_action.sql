﻿if object_id('products_buffer_action') is not null drop proc products_buffer_action
go
create proc products_buffer_action
	@mol_id int,
	@action varchar(32),
	@manager_id int = null
as
begin

    set nocount on;

	declare @buffer_id int = dbo.objs_buffer_id(@mol_id)
	declare @buffer as app_pkids; insert into @buffer select id from dbo.objs_buffer(@mol_id, 'P')

BEGIN TRY
BEGIN TRANSACTION

	if @action = 'CheckAccess' 
	begin
		if dbo.isinrole(@mol_id, 'Products.Admin,Admin') = 0
		begin
			raiserror('У Вас нет доступа к модерации справочника товаров. Роли доступа: Products.Admin, Admin', 16, 1)
		end
	end

	else if @action = 'AddAttrs' 
	begin
		exec products_buffer_action @mol_id = @mol_id, @action = 'CheckAccess'

		delete x from products_attrs x
			join @buffer i on i.id = x.product_id
			join products_attrs attr on attr.product_id = -@mol_id and attr.attr_id = x.attr_id
		where attr.attr_value is not null
			
		insert into products_attrs(product_id, attr_id, attr_value, add_mol_id)
		select distinct x.product_id, attr.attr_id, attr.attr_value, @mol_id
		from products x
			join @buffer i on i.id = x.product_id
			join products_attrs attr on attr.product_id = -@mol_id
		where attr.attr_value is not null
	end

	else if @action = 'RemoveAttrs' 
	begin
		exec products_buffer_action @mol_id = @mol_id, @action = 'CheckAccess'

		delete x from products_attrs x
			join @buffer i on i.id = x.product_id
			join products_attrs attr on attr.product_id = -@mol_id and attr.attr_id = x.attr_id
	end

	else if @manager_id is not null
	begin
		exec products_buffer_action @mol_id = @mol_id, @action = 'CheckAccess'

		declare @attr_id int = (select top 1 attr_id from prodmeta_attrs where code = 'закупка.КодМенеджера')
		
		delete x from products_attrs x
			join @buffer i on i.id = x.product_id and x.attr_id = @attr_id

		insert into products_attrs(product_id, attr_id, attr_value, attr_value_note)
		select id, @attr_id, mols.mol_id, mols.name
		from @buffer i
			join mols on mols.mol_id = @manager_id
	end

COMMIT TRANSACTION
END TRY

BEGIN CATCH
	IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION
	declare @err varchar(max); set @err = error_message()
	raiserror (@err, 16, 3)
END CATCH -- TRANSACTION

end
go
