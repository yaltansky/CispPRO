﻿if object_id('ti_tasks') is not null drop trigger ti_tasks
go
create trigger ti_tasks on tasks
for insert
as begin
 
	set nocount on;
	
	update t
	set title = concat(p.name, ' / ', isnull(t.title, pt.name)),
		d_deadline = isnull(t.d_deadline, pt.d_to),
		analyzer_id = isnull(t.analyzer_id,
			(select top 1 mol_id from projects_tasks_raci where task_id = pt.task_id and raci like '%R%')
			)
	from tasks t
		join projects_tasks pt on pt.task_id = t.project_task_id
		    join projects p on p.project_id = pt.project_id
	where t.task_id in (select task_id from inserted)

end
go
