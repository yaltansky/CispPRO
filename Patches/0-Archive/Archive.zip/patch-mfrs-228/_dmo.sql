IF OBJECT_ID('MFR_SDOCS_PRIORITIES') IS NOT NULL DROP TABLE MFR_SDOCS_PRIORITIES
GO

CREATE TABLE MFR_SDOCS_PRIORITIES(
    PRIORITY_ID INT PRIMARY KEY,	
    PRIORITY_MAX INT,
    NAME VARCHAR(50),
    CSS VARCHAR(250)
)
GO

INSERT INTO MFR_SDOCS_PRIORITIES(PRIORITY_ID, PRIORITY_MAX, NAME, CSS)
VALUES
    (0, 99, 'высший', 'badge bg-danger text-xx-small opaque mb-1'),
    (100, 199, 'высокий', 'badge bg-primary text-xx-small opaque mb-1'),
    (200, 399, 'средний', 'badge bg-secondary text-xx-small opaque mb-1'),
    (400, 500, 'низкий', 'badge bg-secondary text-xx-small opaque mb-1')
GO
