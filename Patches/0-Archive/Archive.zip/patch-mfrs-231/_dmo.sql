IF DBO.COLUMN_ID('SDOCS.EXT_TYPE_ID') IS NULL
    ALTER TABLE SDOCS ADD 
        EXT_TYPE_ID INT,
        EXT_PROBABILITY_ID INT,
        EXT_STATUS_ID INT
GO

IF OBJECT_ID('MFR_EXT_PROBABILITIES') is null
BEGIN
    -- DROP TABLE MFR_EXT_PROBABILITIES
    CREATE TABLE MFR_EXT_PROBABILITIES(
        PROBABILITY_ID INT PRIMARY KEY,
        NAME VARCHAR(50),
        STYLE VARCHAR(MAX)
    )
    INSERT INTO MFR_EXT_PROBABILITIES(PROBABILITY_ID, NAME, STYLE)
    VALUES 
        (1, 'Вероятность 80%', 'background-color: lightcoral'),
        (2, 'Вероятность 90%', 'background-color: lightskyblue'),
        (3, 'Вероятность >95%', 'background-color: cornflowerblue')
END
GO

IF OBJECT_ID('MFR_EXT_TYPES') is null
BEGIN
    CREATE TABLE MFR_EXT_TYPES(
        TYPE_ID INT PRIMARY KEY,
        NAME VARCHAR(50)
    )
    INSERT INTO MFR_EXT_TYPES(TYPE_ID, NAME)
    VALUES 
        (1, 'Прогнозный заказ')
END
GO

IF OBJECT_ID('MFR_EXT_STATUSES') is null
BEGIN
    CREATE TABLE MFR_EXT_STATUSES(
        STATUS_ID INT PRIMARY KEY,
        NAME VARCHAR(50)
    )
    INSERT INTO MFR_EXT_STATUSES(STATUS_ID, NAME)
    VALUES 
        (0, 'Черновик'),
        (1, 'Открыт'),
        (-100, 'Архив'),
        (-99, 'Отменён')
END
GO

IF DBO.COLUMN_ID('MFR_PLANS_VERS.INCLUDE_FORECAST') IS NULL
    ALTER TABLE MFR_PLANS_VERS ADD INCLUDE_FORECAST BIT
GO
