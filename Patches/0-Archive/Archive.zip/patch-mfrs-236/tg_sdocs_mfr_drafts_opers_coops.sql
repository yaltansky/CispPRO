﻿if object_id('tg_sdocs_mfr_drafts_opers_coops') is not null drop trigger tg_sdocs_mfr_drafts_opers_coops
go
create trigger tg_sdocs_mfr_drafts_opers_coops on SDOCS_MFR_DRAFTS_OPERS_COOPS
for insert, update, delete as
begin

	set nocount on;
	if dbo.sys_triggers_enabled() = 0 return -- disabled

	update x
	set count_resources = xx.c_rows
	from sdocs_mfr_drafts_opers x
		left join (
			select oper_id, count(*) as c_rows
			from sdocs_mfr_drafts_opers_coops
			group by oper_id
		) xx on xx.oper_id = x.oper_id
	where x.oper_id in (
		select oper_id from inserted
		union select oper_id from deleted
		)
end
GO
