delete from app_registry where registry_id like 'products_buffer_action%'

insert into app_registry(registry_id, val_number, val_date, val_string)
values 
    ('products_buffer_action:Admin', null, null, 'Admin,Products.Admin,Mfr.Admin.Materials'),
    ('products_buffer_action:Any', null, null, 'Admin,Products.Admin,Mfr.Admin.Materials')
GO
