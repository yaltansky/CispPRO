﻿if object_id('tu_findocs_accounts') is not null drop trigger tu_findocs_accounts
go
create trigger tu_findocs_accounts on dbo.FINDOCS_ACCOUNTS
for update as
begin

	set nocount on;

    -- delete virtual deleted
        delete fd from findocs fd
            join inserted i on i.account_id = fd.account_id
        where i.is_deleted = 1
            and fd.status_id = -1

    -- check existence
        if exists(
            select 1 from findocs fd
                join inserted i on i.account_id = fd.account_id
            where i.is_deleted = 1
            )
        begin
            RAISERROR('Нельзя удалить связанные с фин. операциями счета.', 16, 1)
            ROLLBACK
        end
end
GO
