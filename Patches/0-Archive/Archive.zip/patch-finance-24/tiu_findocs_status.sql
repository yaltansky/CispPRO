﻿if exists(select 1 from sys.objects where name = 'tiu_findocs_status')
	drop trigger tiu_findocs_status
go

create trigger tiu_findocs_status on FINDOCS
for insert, update
as
begin
	
	if dbo.sys_triggers_enabled() = 0 return -- disabled

	set nocount on;

	if update(budget_id) or update(article_id) or update(has_details)
	begin
		update fd
		set status_id = 
				case 
					when fd.status_id = -1 then -1
					when fd.has_details = 1 then 
						case
							when exists(select 1 from findocs_details where findoc_id = fd.findoc_id and (isnull(budget_id,0) = 0 or isnull(article_id,0) = 0)) 
								then 0
							else 1
						end
					when isnull(fd.budget_id,0) <> 0 and isnull(fd.article_id,0) <> 0 then 1
					else 0
				end
		from findocs fd
			join inserted i on i.findoc_id = fd.findoc_id
	end

end
