﻿if object_id('tiud_findocs_materials') is not null drop trigger tiud_findocs_materials
-- go
-- create trigger tiud_findocs_materials on FINDOCS_MATERIALS
-- for insert, update, delete
-- as
-- begin

-- 	set nocount on;

-- 	if dbo.sys_triggers_enabled() = 0 return -- disabled

-- 	if update(value_ccy)
-- 		update fd
-- 		set value_rur = 
-- 				case
-- 					when f.ccy_id = 'rur' then fd.value_ccy
-- 					else fd.value_ccy * (f.value_rur / nullif(f.value_ccy,0))
-- 				end
-- 		from findocs_materials fd
-- 			join findocs f on f.findoc_id = fd.findoc_id
-- 		where fd.findoc_id in (select findoc_id from inserted)

-- end
-- go
