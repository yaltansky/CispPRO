﻿-- dbcontext: CISP
-- OBJS_TYPES
IF DBO.COLUMN_ID('OBJS_TYPES.IS_EXPORT') IS NULL
BEGIN
	ALTER TABLE OBJS_TYPES ADD IS_EXPORT BIT
	EXEC SP_EXECUTESQL N'
		UPDATE OBJS_TYPES SET IS_EXPORT = 1 WHERE TYPE IN (
			''FD'', ''DL'', ''SD'', ''MFTRF''
		)
		'
END
GO

IF DBO.COLUMN_ID('OBJS_TYPES.BASE_TABLE') IS NULL
BEGIN
	ALTER TABLE OBJS_TYPES ADD 
        BASE_TABLE VARCHAR(100),
        BASE_TABLE_COLUMN VARCHAR(100)

	EXEC SP_EXECUTESQL N'
    UPDATE OBJS_TYPES SET 
        BASE_TABLE = 
            CASE FOLDER_KEYWORD
                WHEN ''AGENT'' THEN ''AGENTS''
                WHEN ''BUDGET'' THEN ''BUDGETS''
                WHEN ''DEALS'' THEN ''DEALS''
                WHEN ''DOCUMENT'' THEN ''DOCUMENTS''
                WHEN ''FINDOC'' THEN ''FINDOCS''
                WHEN ''INVOICE'' THEN ''SUPPLY_INVOICES''
                WHEN ''MFC'' THEN ''SDOCS_MFR_ITEMS''
                WHEN ''MFD'' THEN ''MFR_DRAFTS''
                WHEN ''MFJ'' THEN ''MFR_PLANS_JOBS''
                WHEN ''MFM'' THEN ''SDOCS_MFR_MATERIALS''
                WHEN ''MFP'' THEN ''MFR_PLANS''
                WHEN ''MFR'' THEN ''MFR_SDOCS''
                WHEN ''MFTRF'' THEN ''V_MFR_SDOCS_TRF''
                WHEN ''MFW'' THEN ''MFR_WK_SHEETS''
                WHEN ''PRODUCT'' THEN ''PRODUCTS''
                WHEN ''PLANPAY'' THEN ''PLAN_PAYS''
                WHEN ''PAYORDER'' THEN ''PAYORDERS''
                WHEN ''PROJECT'' THEN ''PROJECTS''
                WHEN ''SDOC'' THEN ''SDOCS''
                WHEN ''TASK'' THEN ''TASKS''
            END,

        BASE_TABLE_COLUMN = 
            CASE FOLDER_KEYWORD
                WHEN ''AGENT'' THEN ''AGENT_ID''
                WHEN ''BUDGET'' THEN ''BUDGET_ID''
                WHEN ''DEALS'' THEN ''DEAL_ID''
                WHEN ''DOCUMENT'' THEN ''DOCUMENT_ID''
                WHEN ''FINDOC'' THEN ''FINDOC_ID''
                WHEN ''INVOICE'' THEN ''DOC_ID''
                WHEN ''MFC'' THEN ''CONTENT_ID''
                WHEN ''MFD'' THEN ''DRAFT_ID''
                WHEN ''MFJ'' THEN ''PLAN_JOB_ID''
                WHEN ''MFM'' THEN ''CONTENT_ID''
                WHEN ''MFP'' THEN ''PLAN_ID''
                WHEN ''MFR'' THEN ''DOC_ID''
                WHEN ''MFTRF'' THEN ''DOC_ID''
                WHEN ''MFW'' THEN ''WK_SHEET_ID''
                WHEN ''PRODUCT'' THEN ''PRODUCT_ID''
                WHEN ''PLANPAY'' THEN ''PLAN_PAY_ID''
                WHEN ''PAYORDER'' THEN ''PAYORDER_ID''
                WHEN ''PROJECT'' THEN ''PROJECT_ID''
                WHEN ''SDOC'' THEN ''DOC_ID''
                WHEN ''TASK'' THEN ''TASK_ID''
            END
    '
END
GO

IF OBJECT_ID('OBJS_META_REFS') IS NULL
BEGIN
	-- DROP TABLE OBJS_META_REFS
	CREATE TABLE OBJS_META_REFS(
		ID INT IDENTITY PRIMARY KEY,
		FROM_OBJ_TYPE VARCHAR(8),
		TO_OBJ_TYPE VARCHAR(30),
		TO_OBJ_NAME VARCHAR(100),
		URL VARCHAR(MAX)
	)
	CREATE UNIQUE INDEX IX_OBJS_META_REFS ON OBJS_META_REFS(FROM_OBJ_TYPE, TO_OBJ_TYPE)
END
GO

DELETE FROM OBJS_META_REFS WHERE FROM_OBJ_TYPE IN (
    'A', 'PO', 'FD', 'SD', 'BDG', 'PRJ', 'DL', 'INV', 'INVPAY'
    )

INSERT INTO OBJS_META_REFS(FROM_OBJ_TYPE, TO_OBJ_TYPE)
VALUES
	('A', 'FD'), ('A', 'DL'), ('A', 'MFR'), ('A', 'DOC'),
	('PO', 'FD'), ('PO', 'BDG'), ('PO', 'DL'), ('PO', 'PRJ'), ('PO', 'INV'),
	
    -- оплаты
    ('FD', 'PO'), 
    ('FD', 'INV'), 
    ('FD', 'BDG'),
    ('FD', 'DL'),
    ('FD', 'PRJ'),
    ('FD', 'A'),

    -- бюджеты
	('BDG', 'FD'), ('BDG', 'PO'), ('BDG', 'PRJ'),

    -- проекты
	('PRJ', 'PO'), ('PRJ', 'FD'), ('PRJ', 'BDG'), ('PRJ', 'DL'),

    -- сделки
	('DL', 'PO'), ('DL', 'FD'), ('DL', 'PRJ'), ('DL', 'A')

INSERT INTO OBJS_META_REFS(FROM_OBJ_TYPE, TO_OBJ_TYPE, TO_OBJ_NAME, URL)
VALUES
	-- Счета поставщиков
	('INV', 'FD', null, null),
	('INV', 'MFC', 'Материалы', '/mfrs/plans/0/materials'),
	('INV', 'INVPAY', null, null),
	('INV', 'SHIPS', 'Приходы', '/sdocs'),
    ('INV', 'P', null, null),
    ('INV', 'PO', null, null),

	-- Журнал счетов и оплат
	('INVPAY', 'INV', null, null),
	('INVPAY', 'INVPAYByInvoices', 'Найти по счетам', '#self'),
	('INVPAY', 'PO', null, null),

	-- Товарные документы
	('SD', 'MFM', 'Приходы --> Материалы', null),
	('SD', 'INV', null, null),
	('SD', 'A', null, null),
	('SD', 'P', null, null)
