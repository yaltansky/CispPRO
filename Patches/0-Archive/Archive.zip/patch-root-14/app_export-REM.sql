-- dbcontext: CISP_REM
	if db_name() not in ('CISP_REM', 'CISP2')
		begin
			raiserror('This procedure is implemented only in CISP_REM', 16, 1)
			return
		end
		if object_id('app_export') is not null drop proc app_export
go
/***
  truncate table app_exports
  declare @group_id uniqueidentifier = newid()
  insert into app_exports(group_id, name, folder_id, obj_type, mol_id) values 
    (@group_id, 'Приходование материалов', 58883, 'SD', 1000),
    (@group_id, 'Выдача материалов', 58867, 'MFTRF', 1000)
  exec app_export @group_id
***/
create proc app_export
  @group_id uniqueidentifier
as
begin
	set nocount on;

  -- build xml
		declare c_exports cursor local read_only for 
			select export_id from app_exports where group_id = @group_id
		
		declare @export_id int
		
		open c_exports; fetch next from c_exports into @export_id
			while (@@fetch_status != -1)
			begin
				if (@@fetch_status != -2) exec app_export;2 @export_id
				fetch next from c_exports into @export_id
			end
		close c_exports; deallocate c_exports

  -- results
    select * from app_exports where group_id = @group_id
end
go
create proc app_export;2
  @export_id int
as
begin
	set nocount on;

  -- параметры
    declare
      @date_from date,
      @date_to date,
      @folder_id int,
      @obj_type varchar(20)

      select
        @date_from = d_from,
        @date_to = d_to,
        @folder_id = folder_id,
        @obj_type = obj_type
      from app_exports
      where export_id = @export_id 

    declare @result table(data xml)

  -- материалы: поступление на склад
    if (@obj_type = 'SD') 
      insert into @result
      exec app_export;20 @export_id, @date_from, @date_to, @folder_id

  -- материалы: выдача в производство
    if (@obj_type = 'MFTRF') 
      insert into @result
      exec app_export;30 @export_id, @date_from, @date_to, @folder_id

  -- save result
    update app_exports set data = (select top 1 data from @result)
    where export_id = @export_id
end
go
-- материалы: поступление на склад
create procedure app_export;20
  @export_id int,
  @date_from date = null,
  @date_to date = null,
  @folder_id int = null
as
begin
  declare @subjectId int = 30
  declare @subjectPrefix varchar(10) = concat(@subjectId, '-')
  declare @objs app_pkids

  -- tables
    create table #docs (
      doc_id int primary key,
      d_doc datetime,
      number varchar(50),
      note varchar(max),
      agent_name varchar(500),
      agent_inn varchar(50),
      d_doc_ext datetime,
      mol_to_id int,
      mol_to_name varchar(255),
      mol_to_extern_id varchar(100),
      acc_register_name varchar(255),
      acc_register_note varchar(max)
      )
    create table #docs_details (
      doc_id int,
      product_id int,
      item_id varchar(32),
      item_name varchar(500),
      mfr_number varchar(50),
      unit_name varchar(20),
      quantity float,
      sum_pc float,
      sum_pct float
      )

  -- @objs
    if (@folder_id is not null) begin
      insert into @objs
      select obj_id
      from objs_folders_details fd
        join sdocs sd on sd.doc_id = fd.obj_id and sd.type_id = 9
      where (folder_id = @folder_id)
        and obj_type = 'SD'

    end else begin
      insert into @objs
        select doc_id from sdocs
        where (type_id = 9) and
            (d_doc between isnull(@date_from,d_doc) and isnull(@date_to, d_doc))
    end

  -- список документов
    insert into #docs(
      doc_id, d_doc, number, note, agent_name, agent_inn, d_doc_ext, mol_to_id, mol_to_name, mol_to_extern_id, acc_register_name, acc_register_note
      )
    select
        h.doc_id, h.d_doc, h.number, h.note, agent_name = a.name, agent_inn = a.inn, h.d_doc_ext,
        h.mol_to_id,
        mol_to_name = concat(m.surname, ' ' + m.name1, ' ' + m.name2),
        mol_to_extern_id = m.tab_number,
        acc_register_name = r.name,
        acc_register_note = r.note
      from
        sdocs h
          left join agents a on (h.agent_id = a.agent_id)
          left join mols m on (h.mol_to_id = m.mol_id)
          left join accounts_registers r on (h.acc_register_id = r.acc_register_id)
          -- фильтр по документам
          join #filter_objs f on (f.id = h.doc_id)

  -- табличная часть
    insert into #docs_details(
      doc_id, product_id, item_id, item_name, mfr_number, unit_name, quantity, sum_pc, sum_pct)
    select
        h.doc_id, p.product_id, e.item_id, item_name = p.name, d.mfr_number,
        unit_name = u.name, d.quantity, sum_pc = d.value_pure, sum_pct = d.value_rur
      from
        #docs h
          join sdocs_products d on (h.doc_id = d.doc_id)
          join products p on (d.product_id = p.product_id)
          left join (
            select e.product_id, item_id = max(substring(extern_id, len(@subjectPrefix) + 1, 50))
              from (
                select product_id, extern_id = ltrim(rtrim(extern_id)) from mfr_replications_products where extern_id like (@subjectPrefix + '%')
              ) e
              group by e.product_id
          ) e on (p.product_id = e.product_id)
          join products_units u on (d.unit_id = u.unit_id)

    -- залечим ITEM_ID из названия
    update d set d.item_id = substring(d.item_name, 2, charindex(']', d.item_name) - 2)
      from #docs_details d
      where
        (d.item_id is null) and
        (left(d.item_name, 1) = '[')

    -- исправим названия
    update d set
        d.item_name = replace(d.item_name, '[' + d.item_id + '] ', '')
      from #docs_details d
      where (d.item_id is not null)

  -- выгрузим в xml
  select
    (
    select
        [@Источник]     = db_name(),
        [@Организация]  = 'РЭМ',
        [@Агент]        = 'CISP',
        [@ВерсияАгента] = '1',
        [@Запрос]       = @export_id,
        [@Папка]        = convert(varchar(20), @folder_id, 104),
        (-- документы
         select (
           select
               [@ДокументКод]        = h.doc_id,
               [@ДокументДата]       = convert(varchar(10), h.d_doc, 104),
               [@ДокументНомер]      = h.number,
               [@ДокументТип]        = 'Поступление материала на склад',
               [@ДокументПримечание] = h.note,
               [@Клиент]             = h.agent_name,
               [@КлиентИНН]          = h.agent_inn,
               [@КлиентДата]         = convert(varchar(10), h.d_doc_ext, 104),
               [@Кладовщик]          = h.mol_to_name,
               [@КладовщикТаб]       = h.mol_to_extern_id,
               [@РазделительКод]     = h.acc_register_name,
               [@РазделительПрим]    = h.acc_register_note,
               (-- табличная часть
                select (
                  select
                      [@ProductId]    = d.product_id,
                      [@Код]          = d.item_id,
                      [@Наименование] = d.item_name,
                      [@Заказ]        = d.mfr_number,
                      [@ЕдИзм]        = d.unit_name,
                      [@Количество]   = cast(d.quantity as decimal(19,6)),
                      [@СуммаБНДС]    = cast(d.sum_pc as decimal(19,6)),
                      [@СуммаСНДС]    = cast(d.sum_pct as decimal(19,6))
                    from #docs_details d
                    where (h.doc_id = d.doc_id)
                    for xml path('Строка'), type
                ) for xml path('Строки'), type
               )
             from #docs h
             for xml path('Документ'), type
         ) for xml path('Документы'), type
        )
      for xml path('Сообщение')
    )

  --
  exec drop_temp_table '#docs,#docs_details'
end
go
-- материалы: выдача в производство
create procedure app_export;30
  @export_id int,
  @date_from date = null,
  @date_to date = null,
  @folder_id int = null
as
begin
  declare @subjectId int = 30
  declare @subjectPrefix varchar(10) = concat(@subjectId, '-')
  declare @objs app_pkids

  -- tables
    create table #docs (
      doc_id int,
      d_doc datetime,
      number varchar(50),
      division_from varchar(50),
      mol_id int,
      mol_name varchar(255),
      mol_extern_id varchar(100),
      division_to varchar(50),
      mol_to_id int,
      mol_to_name varchar(255),
      mol_to_extern_id varchar(100),
      acc_register_name varchar(255),
      acc_register_note varchar(max),
      note varchar(max)
      )
    create table #docs_details (
      doc_id int,
      product_id int,
      item_id varchar(32),
      item_name varchar(500),
      mfr_doc_no varchar(50),
      unit_name varchar(20),
      quantity float
      )

  -- @objs
    if (@folder_id is not null) begin
      insert into @objs
      select obj_id
      from objs_folders_details
      where (folder_id = @folder_id)
        and obj_type = 'MFTRF'

    end else begin
      insert into @objs
        select obj_id = doc_id
        from sdocs
        where (type_id = 12)
          and (d_doc between isnull(@date_from,d_doc) and isnull(@date_to, d_doc))
    end

  -- список документов
    insert into #docs(
      doc_id, d_doc, number, division_from, mol_id, mol_name, mol_extern_id, division_to, mol_to_id, mol_to_name, mol_to_extern_id, note, acc_register_name, acc_register_note)
    select
        h.doc_id, h.d_doc, h.number,
        division_from = p1.name,
        mol_id        = m1.mol_id,
        mol_name      = concat(m1.surname, ' ' + m1.name1, ' ' + m1.name2),
        mol_extern_id = m1.tab_number,
        division_to   = p2.name,
        mol_to_id     = m2.mol_id,
        mol_to_name   = concat(m2.surname, ' ' + m2.name1, ' ' + m2.name2),
        mol_to_extern_id = m2.tab_number,
        note          = h.note,
        acc_register_name = r.name,
        acc_register_note = r.note
      from
        sdocs h
          left join mfr_places p1 on (h.place_id = p1.place_id)
          left join mols m1 on (h.mol_id = m1.mol_id)
          left join mfr_places p2 on (h.place_to_id = p2.place_id)
          left join mols m2 on (h.mol_to_id = m2.mol_id)
          left join accounts_registers r on (h.acc_register_id = r.acc_register_id)
          -- фильтр по документам
          join #filter_objs f on (h.doc_id = f.id)

  -- табличная часть
    insert into #docs_details (doc_id, product_id, item_id, item_name, mfr_doc_no, unit_name, quantity)
      select h.doc_id, p.product_id, e.item_id, item_name = ltrim(rtrim(p.name)), mfr_doc_no = d.mfr_number, unit_name = u.name, d.quantity
        from
          #docs h
            join sdocs_products d on (h.doc_id = d.doc_id)
            join products p on (d.product_id = p.product_id)
            left join (
              select e.product_id, item_id = max(substring(extern_id, len(@subjectPrefix) + 1, 50))
                from (
                  select product_id, extern_id = ltrim(rtrim(extern_id)) from mfr_replications_products where extern_id like (@subjectPrefix + '%')
                ) e
                group by e.product_id
            ) e on (p.product_id = e.product_id)
            join products_units u on (d.unit_id = u.unit_id)

    -- залечим ITEM_ID из названия
      update d set d.item_id = substring(d.item_name, 2, charindex(']', d.item_name) - 2)
        from #docs_details d
        where
          (d.item_id is null) and
          (left(d.item_name, 1) = '[')

    -- исправим названия
      update d set
          d.item_name = replace(d.item_name, '[' + d.item_id + '] ', '')
        from #docs_details d
        where (d.item_id is not null)

  -- выгрузим в xml
  select
    (
    select
        [@Источник]     = db_name(),
        [@Организация]  = 'РЭМ',
        [@Агент]        = 'CISP',
        [@ВерсияАгента] = '1',
        [@Запрос]       = @export_id,
        [@Папка]        = convert(varchar(20), @folder_id, 104),
        (-- документы
         select (
           select
               [@ДокументКод]     = h.doc_id,
               [@ДокументДата]    = convert(varchar(10), h.d_doc, 104),
               [@ДокументНомер]   = h.number,
               [@ДокументТип]     = 'Выдача материала в производство',
               [@Примечание]      = h.note,
               [@ПодразделениеИз] = h.division_from,
               [@КладовщикИз]     = h.mol_name,
               [@КладовщикИзТаб]  = h.mol_extern_id,
               [@ПодразделениеВ]  = h.division_to,
               [@КладовщикВ]      = h.mol_to_name,
               [@КладовщикВТаб]   = h.mol_to_extern_id,
               [@РазделительКод]  = h.acc_register_name,
               [@РазделительПрим] = h.acc_register_note,
               (-- табличная часть
                select (
                  select
                      [@ProductId]      = d.product_id,
                      [@Код]            = d.item_id,
                      [@Наименование]   = d.item_name,
                      [@Заказ]          = d.mfr_doc_no,
                      [@ЕдИзм]          = d.unit_name,
                      [@КоличествоФакт] = cast(d.quantity as decimal(19,6))
                    from #docs_details d
                    where (h.doc_id = d.doc_id)
                    for xml path('Строка'), type
                ) for xml path('Строки'), type
               )
             from #docs h
             for xml path('Документ'), type
         ) for xml path('Документы'), type
        )
      for xml path('Сообщение')
    )

  --
  exec drop_temp_table '#docs,#docs_details'
end
go
