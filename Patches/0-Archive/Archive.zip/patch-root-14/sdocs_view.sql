﻿if object_id('sdocs_view') is not null drop proc sdocs_view
go
-- exec sdocs_view 1000
create proc sdocs_view
	@mol_id int,
	-- filter		
	@acc_register_id int = null,
	@subject_id int = null,
	@type_id int = null,	
	@d_doc_from date = null,
	@d_doc_to date = null,
	@bunk_id int = null,	
	@status_id int = null,	
	@author_id int = null,
	@agent_id int = null,
	@folder_id int = null,
	@buffer_operation int = null, -- 1 add rows to buffer, 2 remove rows from buffer
	@search nvarchar(100) = null,
	@extra_id int = null,
	-- sorting, paging
	@sort_expression varchar(50) = null,
	@offset int = 0,
	@fetchrows int = 30,
	--
	@rowscount int = null out,
	@trace bit = 0
as
begin

	set nocount on;

	if (@offset = 0 or @buffer_operation is not null)
		or not exists(select 1 from sdocs_cache where mol_id = @mol_id)
	begin
	-- select, then cache results		
		exec sdocs_view;10
			@mol_id = @mol_id,			
			@acc_register_id = @acc_register_id,
			@subject_id = @subject_id,
			@type_id = @type_id,
			@status_id = @status_id,
			@bunk_id = @bunk_id,
			@d_doc_from = @d_doc_from,
			@d_doc_to = @d_doc_to,
			@author_id = @author_id,
			@folder_id = @folder_id,
			@buffer_operation = @buffer_operation,
			@search = @search,
			@extra_id = @extra_id,
			@sort_expression = @sort_expression,
			@offset = @offset,
			@fetchrows = @fetchrows,			
			@rowscount = @rowscount out,
			@trace = @trace
	end

	-- use cache
	else begin
		select
			X.DOC_ID,
			X.D_DOC,
			X.NUMBER,
			SUBJECT_NAME = SUBJECTS.SHORT_NAME,
			TYPE_NAME = TYPES.NAME,
			STATUS_NAME = STATUSES.NAME,
			BUNK_NAME = BUNKS.NAME,
			AGENT_NAME = AGENTS.NAME,
			MOL_NAME = MOLS.NAME,
			X.CCY_ID,
			X.VALUE_CCY,
			X.NOTE
		from sdocs x
			join sdocs_cache xx on xx.mol_id = @mol_id and xx.doc_id = x.doc_id
			join sdocs_types types on types.type_id = x.type_id
			join sdocs_statuses statuses on statuses.status_id = x.status_id
			left join subjects on subjects.subject_id = x.subject_id
			left join sdocs_bunks bunks on bunks.bunk_id = x.bunk_id
			left join agents on agents.agent_id = x.agent_id
			left join mols on mols.mol_id = x.mol_id
		order by xx.id
		offset @offset rows fetch next @fetchrows rows only

		set @rowscount = (select count(*) from sdocs_cache where mol_id = @mol_id)

	end
end
GO
create proc sdocs_view;10
	@mol_id int,
	-- filter	
	@acc_register_id int = null,
	@subject_id int = null,
	@type_id int = null,
	@status_id int = null,
	@bunk_id int = null,
	@d_doc_from date = null,
	@d_doc_to date = null,
	@author_id int = null,
	@folder_id int = null,
	@buffer_operation int = null,
	@search nvarchar(100) = null,
	@extra_id int = null,
	@sort_expression varchar(50) = null,	
	@offset int = 0,
	@fetchrows int = 30,	
	@cacheonly bit = 0,
	--
	@rowscount int out,
	@trace bit = 0
as
begin

-- @objects by reglament
	create table #subjects(id int primary key)
	insert into #subjects select subject_id from subjects
	
	create table #ids(id int primary key)
	if @folder_id = -1 set @folder_id = dbo.objs_buffer_id(@mol_id)
	insert into #ids select obj_id from objs_folders_details
	where folder_id = @folder_id and obj_type in ('sd', 'inv')

-- cast @search
	declare @doc_id int
		
	if dbo.hashid(@search) is not null
	begin
		set @doc_id = dbo.hashid(@search)
		set @search = null
	end
	else
		set @search = '%' + replace(@search, ' ', '%') + '%'

	-- products
	create table #search_ids(id int primary key)
	if exists(
		select 1 from sdocs_products sp
			join sdocs sd on sd.doc_id = sp.doc_id
		where product_id in (select product_id from products where name like @search)
			and sd.type_id not in (5,8,10,11)
		)
		insert into #search_ids
		select distinct sd.doc_id from sdocs_products sp
			join sdocs sd on sd.doc_id = sp.doc_id
		where product_id in (select product_id from products where name like @search)
			and sd.type_id not in (5,8,10,11)
	
-- prepare sql
	declare @sql nvarchar(max), @fields nvarchar(max)

	declare @where nvarchar(max) = concat(
		N' where (@doc_id is null or x.doc_id = @doc_id) '
		
		, case when not exists(select 1 from #ids) then 'and (x.type_id not in (5,8,10,11))' end
		
		, case when @acc_register_id is not null then concat(' and (x.acc_register_id = ', @acc_register_id, ')') end
		, case when @subject_id is not null then concat(' and (x.subject_id = ', @subject_id, ')') end
		, case when @type_id is not null then concat(' and (x.type_id = ', @type_id, ')') end
		, case when @bunk_id is not null then ' and (x.bunk_id = @bunk_id)' end

		, case 
			when @status_id = -2 then concat(' and (x.status_id = 0 and x.add_mol_id = ', @mol_id, ')')
			when @status_id is not null then concat(' and (x.status_id = ', @status_id, ')') 
			when @folder_id is null and @search is null then ' and (x.status_id <> -1)'
			end

		, case when @d_doc_from is not null then ' and (x.d_doc >= @d_doc_from)' end		
		, case when @d_doc_to is not null then ' and (x.d_doc <= @d_doc_to)' end
		, case when @author_id is not null then concat(' and (x.add_mol_id = ', @author_id, ')') end
		, case when @search is not null then 'and (x.content like @search or exists(select 1 from #search_ids where id = x.doc_id))' end
		)

	declare @fields_base nvarchar(max) = N'		
		@d_doc_from date,
		@d_doc_to date,
		@bunk_id int,
		@search nvarchar(200),
		@doc_id int,
		@extra_id int
	'

	declare @inner nvarchar(max) = N'
		join #subjects sx on sx.id = isnull(x.subject_id,0)
		join sdocs_types types on types.type_id = x.type_id
		join sdocs_statuses statuses on statuses.status_id = x.status_id
		left join subjects on subjects.subject_id = x.subject_id
		left join sdocs_bunks bunks on bunks.bunk_id = x.bunk_id
		left join agents on agents.agent_id = x.agent_id
		left join mols on mols.mol_id = x.mol_id 
		left join mols m2 on m2.mol_id = x.add_mol_id 
		'
		+ case when @folder_id is null then '' else ' join #ids ids on ids.id = x.doc_id ' end
		
	if @buffer_operation is not null
	begin
		set @rowscount = -1 -- dummy

		declare @buffer_id int; select @buffer_id = folder_id from objs_folders where keyword = 'BUFFER' and add_mol_id = @mol_id

		if @buffer_operation = 1
		begin
			-- add to buffer
			set @sql = N'
				delete from objs_folders_details where folder_id = @buffer_id and obj_type = ''SD'';
				insert into objs_folders_details(folder_id, obj_type, obj_id, add_mol_id)
				select @buffer_id, ''SD'', x.doc_id, @mol_id from sdocs x '
				+ @inner + @where
			set @fields = @fields_base + ', @buffer_id int, @mol_id int'

			exec sp_executesql @sql, @fields,
				@d_doc_from, @d_doc_to, @bunk_id,
				@search, @doc_id, @extra_id,
				@buffer_id, @mol_id
		end

		else if @buffer_operation = 2
		begin
			-- remove from buffer
			set @sql = N'
				delete from objs_folders_details
				where folder_id = @buffer_id
					and obj_type = ''SD''
					and obj_id in (select doc_id from sdocs x ' + @where + ')'
			set @fields = @fields_base + ', @buffer_id int'
			
			exec sp_executesql @sql, @fields,
				@d_doc_from, @d_doc_to, @bunk_id,
				@search, @doc_id, @extra_id,
				@buffer_id
		end
	end

	else 
	begin
		-- @rowscount
		if @cacheonly = 0
		begin
			DECLARE @hint VARCHAR(50) = ' OPTION (RECOMPILE, OPTIMIZE FOR UNKNOWN)'
			
			set @sql = N'select @rowscount = count(*) from sdocs x ' + @inner + @where
			set @sql = @sql + @hint

			set @fields = @fields_base + ', @rowscount int out'

			if @trace = 1 print 'count(*): ' + @sql + char(10)

			exec sp_executesql @sql, @fields,
				@d_doc_from, @d_doc_to, @bunk_id,
				@search, @doc_id, @extra_id,
				@rowscount out
		end
		
		-- @order_by
		declare @order_by nvarchar(50) = N' order by x.d_doc, x.number'

		if @sort_expression is not null
		begin
			if charindex('value_ccy', @sort_expression) = 1 begin
				set @sort_expression = replace(@sort_expression, 'value_ccy', 'abs(value_ccy)')
				set @sort_expression = @sort_expression + ', d_doc'
			end
			set @order_by = N' order by ' + @sort_expression
		end

		delete from sdocs_cache where mol_id = @mol_id

		declare @subquery nvarchar(max) = N'
(
	select
		X.DOC_ID,
		X.D_DOC,
		X.NUMBER,
		SUBJECT_NAME = SUBJECTS.SHORT_NAME,
		TYPE_NAME = TYPES.NAME,
		STATUS_NAME = STATUSES.NAME,
		BUNK_NAME = BUNKS.NAME,
		AGENT_NAME = AGENTS.NAME,
		MOL_NAME = MOLS.NAME,
		ADD_MOL_NAME = M2.NAME,
		X.VALUE_CCY,
		X.CCY_ID,
		X.NOTE
	from sdocs x '
+ @inner + @where
+' ) x ' + @order_by

		-- cache
		if isnull(@rowscount,0) < 5000 or @cacheonly = 1
		begin			
			declare @sql_cache nvarchar(max) = N'
				insert into sdocs_cache(mol_id, doc_id)
				select @mol_id, x.doc_id
				from ' + @subquery
			set @sql_cache = @sql_cache + @hint
			set @fields = @fields_base + ', @mol_id int'

			exec sp_executesql @sql_cache, @fields,
				@d_doc_from, @d_doc_to, @bunk_id,
				@search,  @doc_id, @extra_id,
				@mol_id
		end

		if @cacheonly = 0
		begin
			-- @sql
			set @sql = N'select x.* from ' + @subquery

			-- optimize on fetch
			if @rowscount > @fetchrows set @sql = @sql + ' offset @offset rows fetch next @fetchrows rows only'

			set @fields = @fields_base + ', @offset int, @fetchrows int'

			if @trace = 1 print '@sql: ' + @sql + char(10)

			exec sp_executesql @sql, @fields,
				@d_doc_from, @d_doc_to, @bunk_id, 
				@search, @doc_id, @extra_id,
				@offset, @fetchrows
		end

	end -- if

	exec drop_temp_table '#subjects,#ids,#search_ids'

end
go
