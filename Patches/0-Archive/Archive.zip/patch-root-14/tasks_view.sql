﻿if object_id('tasks_view') is not null drop proc tasks_view
go
-- exec tasks_view @mol_id = 1000, @filter_xml = '<f><EXTRA_ID>1</EXTRA_ID></f>'
create proc tasks_view
	@mol_id int,	
	@use_cache bit = 0,
	@filter_xml xml = null,
	-- 
	@sort_expression varchar(50) = null,
	@offset int = 0,
	@fetchrows int = 30,
	@rowscount int = null out,
	-- 
	@trace bit = 0
as
begin

	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

	-- parse filter
		declare 
			@project_id int,	
			@project_task_id int,	
			@theme_id int,
			@author_id int,
			@analyzer_id int,
			@executor_id int,
			@role_mol_id int,
			@admin_counter_id int,
			@status_id int,
			@extra_id int,
			@event_id int,
			@search varchar(max),
			@search_hist bit,
			@refkey varchar(250),
			@d_doc_from date,
			@d_doc_to date,
			@d_deadline_from date,
			@d_deadline_to date,
			@d_hist_from date,
			@d_hist_to date,
			@d_closed_from date,
			@d_closed_to date,
			@folder_id int,
			@buffer_operation int

		declare @handle_xml int; exec sp_xml_preparedocument @handle_xml output, @filter_xml
			select
				@project_id = nullif(project_id, 0),
				@project_task_id = nullif(project_task_id, 0),
				@theme_id = nullif(theme_id, 0),
				@author_id = nullif(author_id, 0),
				@analyzer_id = nullif(analyzer_id, 0),
				@executor_id = nullif(executor_id, 0),
				@role_mol_id = nullif(role_mol_id, 0),
				@admin_counter_id = nullif(admin_counter_id, 0),
				@status_id = @filter_xml.value('(/*/STATUS_ID/text())[1]', 'int'),
				@extra_id = nullif(extra_id,0),
				@event_id = nullif(event_id,0),
				@search = Search,
				@search_hist = isnull(SearchHist,0),
				@refkey = refkey,
				@d_doc_from = nullif(d_doc_from,'1900-01-01'),
				@d_doc_to = nullif(d_doc_to,'1900-01-01'),
				@d_deadline_from = nullif(d_deadline_from,'1900-01-01'),
				@d_deadline_to = nullif(d_deadline_to,'1900-01-01'),
				@d_hist_from = nullif(d_hist_from,'1900-01-01'),
				@d_hist_to = nullif(d_hist_to,'1900-01-01'),
				@d_closed_from = nullif(d_closed_from,'1900-01-01'),
				@d_closed_to = nullif(d_closed_to,'1900-01-01'),
				@folder_id = nullif(folder_id,0),
				@buffer_operation = nullif(buffer_operation,0)
			from openxml (@handle_xml, '/*', 2) with (
				PROJECT_ID INT,	
				PROJECT_TASK_ID INT,	
				THEME_ID INT,
				AUTHOR_ID INT,
				ANALYZER_ID INT,
				EXECUTOR_ID INT,
				ROLE_MOL_ID INT,
				ADMIN_COUNTER_ID INT,
				STATUS_ID INT,
				EXTRA_ID INT,
				EVENT_ID INT,
				Search VARCHAR(MAX),
				SearchHist BIT,
				REFKEY VARCHAR(250),
				D_DOC_FROM DATE,
				D_DOC_TO DATE,
				D_DEADLINE_FROM DATE,
				D_DEADLINE_TO DATE,
				D_HIST_FROM DATE,
				D_HIST_TO DATE,
				D_CLOSED_FROM DATE,
				D_CLOSED_TO DATE,
				FOLDER_ID INT,
				BUFFER_OPERATION INT
				)
		exec sp_xml_removedocument @handle_xml

	declare @tasks_cache varchar(50) = concat('CISPTMP.dbo.TASKS_CACHE$', @mol_id)
	exec tasks_view;3 @mol_id -- auto-create cache table

	-- prepare params
		declare @inout_status_id int
		if @status_id <= -10 -- Виртуальные статусы
		begin
			set @inout_status_id = @status_id
			set @status_id = null
			if @inout_status_id = -10 set @sort_expression = null -- упорядочение по дате уведомления
		end

	declare @sql nvarchar(max), @select_filelds nvarchar(max), @from nvarchar(max), @fields_base nvarchar(max), @fields nvarchar(max)

	-- create cache (if needed)
		if @offset = 0 and @use_cache = 0
			exec tasks_view;10 
				@mol_id = @mol_id,
				@refkey = @refkey,
				@theme_id = @theme_id,
				@admin_counter_id = @admin_counter_id,
				@inout_status_id = @inout_status_id,
				@project_id = @project_id,
				@project_task_id = @project_task_id,
				@author_id = @author_id,
				@analyzer_id = @analyzer_id,
				@executor_id = @executor_id,
				@role_mol_id = @role_mol_id,
				@extra_id = @extra_id,
				@event_id = @event_id,
				@folder_id = @folder_id,
				@search = @search,
				@trace = @trace

	-- @task_id
		declare @task_id int = dbo.hashid(@search)
		if @task_id is not null set @search = null -- поиск по коду задачи
		if exists(select 1 from dbo.hashids(@search)) set @search = null -- поиск по нескольким кодам задач

	-- final select
		declare @today date = dbo.today()
			
		set @search = '%' + @search + '%'
		
		set @select_filelds = N'
			t.*,
			ids.*,
			ts.status_id,
			status_name = ts.name,
			status_css = ts.css_class,
			foundex = 
				case
					when @search is null then 0
					when t.title like @search then 1
					else 2
				end
			'

		set @from = concat('
		from v_tasks t
			join <tasks_cache> ids on ids.task_id = t.task_id
				left join tasks_statuses ts on ts.status_id = ids.status_id
		where (1 = 1)',
			
			case when @task_id is not null then ' and (t.task_id = @task_id)' end,
			case when @refkey is not null then ' and (t.refkey = @refkey)' end,
			
			case when @inout_status_id is not null then ' and (
				   (@inout_status_id = -10 and ids.is_input = 1)
				or (@inout_status_id = -20 and ids.is_output = 1)
				or (@inout_status_id = -30 and ts.is_working = 1)
				)' 
			end,

			case when @status_id is not null then ' and (ts.status_id = @status_id)' end,
			
			case when @search is not null then ' and (
				t.title like @search
				or (@search_hist = 1 and exists(select 1 from tasks_hists where task_id = t.task_id and body like @search)
				)' 
			end,

			case when @d_doc_from is not null then ' and (t.d_doc >= @d_doc_from)' end,
			case when @d_doc_to is not null then ' and (t.d_doc <= @d_doc_to)' end,
			case when @d_deadline_from is not null then ' and (t.d_deadline >= @d_deadline_from)' end,
			case when @d_deadline_to is not null then ' and (t.d_deadline <= @d_deadline_to)' end,
			case when @d_hist_from is not null then ' and exists(select 1 from tasks_hists where task_id = t.task_id and d_add >= @d_hist_from)' end,
			case when @d_hist_to is not null then ' and exists(select 1 from tasks_hists where task_id = t.task_id and d_add <= @d_hist_to)' end,
			case when @d_closed_from is not null then ' and (t.d_closed >= @d_closed_from)' end,
			case when @d_closed_to is not null then ' and (t.d_closed <= @d_closed_to)' end
		)

		set @from = replace(@from, '<tasks_cache>', @tasks_cache)

		set @fields_base = N'
			@mol_id int,
			@task_id int,
			@search varchar(max),		
			@search_hist bit,
			@refkey varchar(250),		
			@inout_status_id int,
			@status_id int,				
			@today date,
			@d_doc_from date,
			@d_doc_to date,
			@d_deadline_from date,
			@d_deadline_to date,
			@d_hist_from date,
			@d_hist_to date,
			@d_closed_from date,
			@d_closed_to date
		'

		if @buffer_operation is null
		begin
			-- @rowscount
				set @sql = N'select @rowscount = count(*) ' + @from
				set @fields = @fields_base + ', @rowscount int out'
				exec sp_executesql @sql, @fields,
					@mol_id, @task_id, @search, @search_hist, @refkey, @inout_status_id, @status_id, @today,
					@d_doc_from, @d_doc_to, @d_deadline_from, @d_deadline_to, @d_hist_from, @d_hist_to, @d_closed_from, @d_closed_to,
					@rowscount out

			-- selection
				set @sql = N'select ' + @select_filelds + @from
				if @sort_expression is null
					if @search is not null 
						set @sql = @sql + ' order by foundex, ids.d_sort desc, t.task_id desc'
					else 
						set @sql = @sql + ' order by t.update_date desc'
				else set @sql = @sql + ' order by t.' + @sort_expression

				set @sql = @sql + ' offset @offset rows fetch next @fetchrows rows only'
				set @fields = @fields_base + ', @offset int, @fetchrows int'

			if @trace = 1 print @sql

			exec sp_executesql @sql, @fields,
				@mol_id, @task_id, @search, @search_hist, @refkey, @inout_status_id, @status_id, @today,
				@d_doc_from, @d_doc_to, @d_deadline_from, @d_deadline_to, @d_hist_from, @d_hist_to, @d_closed_from, @d_closed_to,
				@offset, @fetchrows
		end

		else begin
			set @rowscount = -1 -- dummy

			declare @buffer_id int; select @buffer_id = folder_id from objs_folders where keyword = 'BUFFER' and add_mol_id = @mol_id

			if @buffer_operation = 1
			begin
				-- add to buffer
				set @sql = N'
					delete from objs_folders_details where folder_id = @buffer_id and obj_type = ''TSK'';
					;insert into objs_folders_details(folder_id, obj_type, obj_id, add_mol_id)
					select @buffer_id, ''TSK'', t.task_id, @mol_id '
					+ @from
					+ ';select top 0 ' + @select_filelds + @from
				set @fields = @fields_base + ', @buffer_id int'

				exec sp_executesql @sql, @fields,
					@mol_id, @task_id, @search, @search_hist, @refkey, @inout_status_id, @status_id, @today,
					@d_doc_from, @d_doc_to, @d_deadline_from, @d_deadline_to, @d_hist_from, @d_hist_to, @d_closed_from, @d_closed_to,
					@buffer_id
			end

			else if @buffer_operation = 2
			begin
				-- remove from buffer
				set @sql = N'
					delete from objs_folders_details
					where folder_id = @buffer_id
						and obj_type = ''TSK''
						and obj_id in (select t.task_id ' + @from + ')
					;select top 0 ' + @select_filelds + @from
				set @fields = @fields_base + ', @buffer_id int'
				
				exec sp_executesql @sql, @fields,
					@mol_id, @task_id, @search, @search_hist, @refkey, @inout_status_id, @status_id, @today,
					@d_doc_from, @d_doc_to, @d_deadline_from, @d_deadline_to, @d_hist_from, @d_hist_to, @d_closed_from, @d_closed_to,
					@buffer_id
			end
		end
end
go
-- helper: totals info
create proc tasks_view;2
	@mol_id int,
	@status_id int = null,	
	@mode int = null -- null - all counters, 1 - themes totals, 2 - themes, 3 - themes leafs
as
begin

	set nocount on;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

	declare @sql nvarchar(max)
	declare @tasks_cache varchar(50) = concat('CISPTMP.dbo.TASKS_CACHE$', @mol_id)
	exec tasks_view;3 @mol_id -- auto-create cache table

	declare @today date = dbo.today()

	declare @inout_status_id int
	if @status_id <= -10 -- Виртуальные статусы
	begin
		set @inout_status_id = @status_id
		set @status_id = null
	end

	create table #tasks (
		task_id int index ix_task, 
		type_id int,
		analyzer_id int,
		theme_id int,
		is_input bit,
		is_output bit,
		status_id int,
		d_sort date,
		d_alert date,
		d_deadline date
		)

	if @mode is null
	begin
		-- use cache
		set @sql = replace('
		insert into #tasks(task_id, type_id, analyzer_id, theme_id, is_input, is_output, status_id, d_sort, d_alert, d_deadline)
		select distinct x.task_id, t.type_id, x.analyzer_id, x.theme_id, x.is_input, x.is_output, x.status_id, x.d_sort, x.d_alert, t.d_deadline
		from <tasks_cache> x
			join tasks t on t.task_id = x.task_id
		', '<TASKS_CACHE>', @tasks_cache)

		exec sp_executesql @sql
	end

	else 
	begin
		-- #tasks dynamically
		declare @is_admin bit = dbo.isinrole(@mol_id, 'Admin')

		insert into #tasks(task_id, type_id, theme_id, status_id, d_deadline)
			select distinct t.task_id, t.type_id, t.theme_id, t.status_id, t.d_deadline
			from (
				select 
					t.task_id, t.type_id, t.theme_id, 
					isnull(tm.status_id, t.status_id) as status_id,
					t.d_deadline
				from tasks t
					-- #STATUS_RULE
					left join tasks_themes_mols ttm on ttm.theme_id = t.theme_id and ttm.mol_id = @mol_id					
					left join tasks_mols tm on tm.task_id = t.task_id and tm.mol_id = @mol_id and tm.role_id = 1 -- исполнитель видит только "свою" часть задачи
						and tm.mol_id != t.analyzer_id -- координатор ...
						and ttm.mol_id is null -- и аудитор должны видеть общий статус задачи
				) t
				join tasks_statuses ts on ts.status_id = t.status_id and ts.is_working = 1
			where 
				-- #REGLAMENT_VIEW
				(
					@is_admin = 1
					or t.task_id in (
						select task_id from tasks_mols 
							join mols on mols.mol_id = tasks_mols.mol_id
						where @mol_id in (mols.mol_id, mols.chief_id)
						)
				)
	end

	declare @counts table(
		counts_type varchar(30),
		counts_id int, name varchar(50),
		css_class varchar(50), css_badge varchar(50),
		counts int, counts_over int,
		parent_id int,
		sort_id int identity
		)

	if @mode is null
	begin
		-- Входящие
		insert into @counts(counts_type, counts_id, name, css_class, counts)
		select 'countByStatuses',
			status_id,
			name,
			css_class,
			(
			select nullif(count(distinct y.task_id), 0)
			from tasks_hists_mols x
				join tasks_hists y on y.hist_id = x.hist_id
				join #tasks t on t.task_id = y.task_id
			where x.mol_id = @mol_id
				and x.d_read is null
			)
		from tasks_statuses
		where status_id = -10

		-- Исходящие
		insert into @counts(counts_type, counts_id, name, css_class)
		select 'countByStatuses',
			status_id,
			name,
			css_class
		from tasks_statuses
		where status_id = -20

		-- Активные
		insert into @counts(counts_type, counts_id, name, css_class, css_badge, counts)
		select 'countByStatuses',
			status_id,
			name,
			css_class,
			css_badge,
			(
				select nullif(count(*), 0)
				from #tasks t
					join tasks_statuses ts on ts.status_id = t.status_id and ts.is_working = 1
			)
		from tasks_statuses
		where status_id = -30

		insert into @counts(counts_type, counts_id, name, css_class, css_badge, counts)
		select 'countByStatuses',
			ts.status_id,
			ts.name,
			ts.css_class,
			ts.css_badge,
			nullif(count(*),0)
		from #tasks t
			join tasks_statuses ts on ts.status_id = t.status_id
		group by ts.status_id, ts.name, ts.css_class, ts.css_badge
		order by ts.status_id
	end

	else begin
			
		declare @mytasks table(theme_id int, task_id int primary key, d_deadline date)
			insert into @mytasks(theme_id, task_id, d_deadline)
			select distinct t.theme_id, t.task_id, t.d_deadline
			from #tasks t
				join tasks_mols tmols on tmols.task_id = t.task_id
					join mols on mols.mol_id = tmols.mol_id
				join tasks_statuses s on s.status_id = t.status_id
			where @mol_id in (mols.mol_id, mols.chief_id)
				and s.is_working = 1

		-- Итоги по темам
		if @mode = 1
		begin

			insert into @counts(counts_type, counts, counts_over)
			select 'countByThemes',
				(
					select count(*) from @mytasks
				),
				(
					select count(*) from @mytasks where d_deadline < @today
				)
		end

		-- Группировка по темам
		if @mode = 2
		begin
			declare @themes table(theme_id int primary key, name varchar(100), parent_id int, level_id int, node hierarchyid, has_childs bit, counts int, counts_over int)
				insert into @themes(theme_id, name, parent_id, level_id, node, has_childs, counts, counts_over)
				select theme_id, name, parent_id, level_id, node, has_childs,
					(
						select count(*) from @mytasks where theme_id = x.theme_id
					),
					(
						select count(*) from @mytasks where theme_id = x.theme_id and d_deadline < @today
					)
				from tasks_themes x
				where x.is_deleted = 0
		
				update x
				set counts = (select sum(counts) from @themes where node.IsDescendantOf(x.node) = 1),
					counts_over = (select sum(counts_over) from @themes where node.IsDescendantOf(x.node) = 1)
				from @themes x

			insert into @counts(counts_type, counts_id, name, counts, counts_over, parent_id)
			select 'countByThemes', theme_id, name, counts, counts_over, parent_id
			from @themes
			order by node
		end
	end -- @mode is not null

	-- final select
	select * from @counts order by sort_id

	exec drop_temp_table '#tasks'
end
go
-- helper: auto-create cache table
create proc tasks_view;3
	@mol_id int
as
begin

	SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

	IF NOT EXISTS(SELECT 1 FROM SYS.DATABASES WHERE NAME = 'CISPTMP')
		CREATE DATABASE CISPTMP -- cisp for temp objects

	declare @sql nvarchar(max)
	declare @tasks_cache varchar(50) = concat('CISPTMP.dbo.TASKS_CACHE$', @mol_id)
		
	if object_id(@tasks_cache) is null
	begin
		set @sql = replace('
	CREATE TABLE <TASKS_CACHE>(
		MOL_ID INT,
		TASK_ID INT INDEX IX_TASK,
		THEME_ID INT,
		ANALYZER_ID INT,
		IS_INPUT BIT,
		IS_OUTPUT BIT,
		STATUS_ID INT,
		D_SORT DATE,
		D_ALERT DATE,
		INOUT_STATUS_ID INT,
		IS_FAVORITE BIT,
		D_DEADLINE DATE,
		IS_EXECUTOR BIT,
		IS_OVERDUE BIT,
		IS_AUDITOR BIT,
		IS_PARTICIPANT BIT,
		PRIORITY_ID INT
	)
	', '<TASKS_CACHE>', @tasks_cache)

		exec sp_executesql @sql
	end
end
go
-- helper: build cache
create proc tasks_view;10
	@mol_id int,
	@refkey varchar(250) = null,
	@theme_id int = null,
	@admin_counter_id int = null,
	@inout_status_id int = null,
	@project_id int = null,
	@project_task_id int = null,
	@author_id int = null,
	@analyzer_id int = null,
	@executor_id int = null,
	@role_mol_id int = null,
	@extra_id int = null,
	@event_id int = null,	
	@folder_id int = null,
	@search varchar(max) = null,
	@trace bit = 0
as
begin

	set nocount on;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	
	declare @sql nvarchar(max)
	declare @tasks_cache varchar(50) = concat('CISPTMP.dbo.TASKS_CACHE$', @mol_id)
	exec tasks_view;3 @mol_id -- auto-create cache table

	declare @today date; set @today = dbo.today()
	declare @is_admin bit = dbo.isinrole(@mol_id, 'Admin')

	-- @ids
		if @folder_id = -1 set @folder_id = dbo.objs_buffer_id(@mol_id)
		declare @ids as app_pkids; insert into @ids exec objs_folders_ids @folder_id = @folder_id, @obj_type = 'tsk'
		
		if not exists(select 1 from @ids)
			insert into @ids select distinct id from dbo.hashids(@search)

	-- clear cache
		set @sql = replace('truncate table <tasks_cache>', '<tasks_cache>', @tasks_cache)	
		exec sp_executesql @sql

	-- @project_id
		if @project_id is not null
		begin		
			set @sql = replace('
			insert into <tasks_cache>(mol_id, task_id, status_id)
			select @mol_id, task_id, status_id from tasks 
			where project_task_id in (
					select task_id from projects_tasks where project_id = @project_id
					)
				and (status_id != -1)
			', '<tasks_cache>', @tasks_cache)
			exec sp_executesql @sql, N'@mol_id int, @project_id int', @mol_id, @project_id
		end

	-- @project_task_id	
		else if @project_task_id is not null
		begin
			declare @node hierarchyid = (select node from projects_tasks where task_id = @project_task_id)
			set @project_id = (select project_id from projects_tasks where task_id = @project_task_id)
			
			set @sql = replace('
			insert into <tasks_cache>(mol_id, task_id, status_id)
			select @mol_id, task_id, status_id from tasks 
			where project_task_id in (
					select task_id from projects_tasks where project_id = @project_id and node.IsDescendantOf(@node) = 1
					)
				and (status_id != -1)
			', '<tasks_cache>', @tasks_cache)
			print '@project_id (2)'
			exec sp_executesql @sql, N'@mol_id int, @project_id int, @node hierarchyid', @mol_id, @project_id, @node
		end
		
		else 
		begin	
			-- track week
				declare @track_week bit; set @track_week = case when @extra_id in (5,6) then 1 else 0 end
				declare @week_start date, @week_end date
				if @track_week = 1
				begin
					set @week_start = dbo.week_start(case when @extra_id = 5 then dbo.today() else dbo.today() + 7 end)
					set @week_end = dateadd(d, 6, @week_start)
				end

			declare @theme hierarchyid = (select node from tasks_themes where theme_id = @theme_id)

			-- @admin_counter_id
				declare @counter_id int, @counter_mol_id int
				if @admin_counter_id is not null
					select @counter_id = parent_id, @counter_mol_id = mol_id from tasks_counters  where NODE_ID = @admin_counter_id

			-- tasks_cache
				set @sql = replace('
					insert into <tasks_cache>(mol_id, task_id, analyzer_id, theme_id, status_id, d_deadline, d_sort, is_favorite, priority_id)
					select distinct @mol_id, tt.task_id, tt.analyzer_id, tt.theme_id, tt.status_id, tt.d_deadline, tt.add_date, tt.is_favorite, tt.priority_id
					from (
						select 
							t.task_id,
							t.refkey,
							status_id = isnull(tm.status_id, t.status_id),
							d_deadline = isnull(tm.d_deadline, t.d_deadline),
							is_favorite =
								case
									when exists(select 1 from tasks_mols where task_id = t.task_id and mol_id = @mol_id and is_favorite = 1) then 1
								end,				
							t.theme_id, tmols.priority_id, t.author_id, t.analyzer_id, t.owner_id, t.add_date
						from tasks t
							-- priority_id
							left join (
								select task_id, max(priority_id) as priority_id
								from tasks_mols where mol_id = @mol_id
								group by task_id
							) tmols on tmols.task_id = t.task_id
							-- #STATUS_RULE					
							left join tasks_themes_mols ttm on ttm.theme_id = t.theme_id and ttm.mol_id = @mol_id					
							left join tasks_mols tm on tm.task_id = t.task_id and tm.mol_id = @mol_id and tm.role_id = 1 -- исполнитель видит только "свою" часть задачи
								and tm.mol_id != t.analyzer_id -- координатор ...
								and ttm.mol_id is null -- и аудитор должны видеть общий статус задачи					
						where 
							-- #REGLAMENT_VIEW
							(
								(@is_admin = 1 and @theme_id is null)
								or @project_task_id is not null
								or t.task_id in (
									select task_id 
									from tasks_mols 
										join mols on mols.mol_id = tasks_mols.mol_id
									where @mol_id in (mols.mol_id, mols.chief_id)
								)
								or @event_id is not null
							)
					
							-- hide deleted
							and (t.status_id != -1)
						) tt
						join tasks_statuses ts on ts.status_id = tt.status_id			
					
					where 1 = 1
						and (
							not exists(select 1 from @ids) or tt.task_id in (select id from @ids)
							)

						and (@refkey is null or tt.refkey = @refkey)

						and (@theme is null 
							or tt.theme_id in (select theme_id from tasks_themes where node.IsDescendantOf(@theme) = 1)
							)

						-- @track_week
						and (@track_week = 0
							or (@track_week = 1 and tt.d_deadline between @week_start and @week_end)
							)

						-- @extra_id
						and (@extra_id is null 
							-- id: 1, name: Мои задачи
							or (@extra_id = 1 and tt.task_id in (
									select task_id from tasks_mols 
									where mol_id = @mol_id and role_id != 2)
										and ts.status_id not in (-1,5)
									)
							
							-- id: 5, name: Задачи этой недели
							or (@extra_id in (5,6) and ts.is_working = 1)
							
							-- id: 7, name: Просроченные задачи
							or (@extra_id = 7 and tt.d_deadline < @today and ts.is_working = 1)

							-- id: 11, name: Приоритетные
							or (@extra_id = 11 and (tt.priority_id is not null and ts.is_working = 1))

							-- id: 12, name: Помеченные
							or (@extra_id = 12 and tt.is_favorite = 1)
							)

						-- @event_id
						and (@event_id is null
							or tt.task_id in (select obj_id from events_objs_refs where event_id = @event_id and obj_type = ''TSK'')
							)

						-- @admin_counter_id
						and (@admin_counter_id is null
							or tt.task_id in (select task_id from tasks_counters_details where counter_id = @counter_id and mol_id = @counter_mol_id)
							)

						and (@author_id is null or tt.author_id = @author_id)
						and (@analyzer_id is null or tt.analyzer_id = @analyzer_id)

						and (@executor_id is null
							or exists(select 1 from tasks_mols where task_id = tt.task_id and mol_id = @executor_id and role_id = 1)
							)

						and (@role_mol_id is null
							or exists(select 1 from tasks_mols where task_id = tt.task_id and mol_id = @role_mol_id)
							)
					', '<tasks_cache>', @tasks_cache)

				if @trace = 1 print @sql

			exec sp_executesql @sql, N'
				@mol_id int,
				@refkey varchar(250),
				@is_admin bit,
				@theme_id int,
				@theme hierarchyid,
				@admin_counter_id int,
				@counter_id int,
				@counter_mol_id int,
				@inout_status_id int,
				@project_id int,
				@project_task_id int,
				@author_id int,
				@analyzer_id int,
				@executor_id int,
				@role_mol_id int,
				@extra_id int,
				@event_id int,
				@track_week bit,
				@week_start date,
				@week_end date,
				@ids app_pkids readonly,
				@today date
				',
				@mol_id, @refkey, @is_admin, @theme_id, @theme, @admin_counter_id, @counter_id, @counter_mol_id, @inout_status_id, @project_id, @project_task_id,
				@author_id, @analyzer_id, @executor_id, @role_mol_id, @extra_id,
				@event_id, @track_week, @week_start, @week_end,
				@ids, @today

			set @sql = replace('
				declare @last_hist_d_add date, @last_hist_mols_d_add date

				-- is_input, is_output, d_sort, d_alert
				update t
				set @last_hist_d_add = (
						select max(h.d_add) 
							from tasks_hists h
							where h.task_id = t.task_id
								and h.mol_id = @mol_id
						),
					@last_hist_mols_d_add = (
						select max(h.d_add) 
							from tasks_hists_mols hm
								join tasks_hists h on h.hist_id = hm.hist_id
							where h.task_id = t.task_id
								and hm.mol_id = @mol_id
						),
					
					is_input = case when @last_hist_mols_d_add is not null then 1 end,
					is_output = case when @last_hist_d_add is not null then 1 end,
					d_sort = 
						case 
							when @inout_status_id = -10 then @last_hist_mols_d_add
							when @inout_status_id = -20 then @last_hist_d_add
							else t.d_sort
						end,
					d_alert = 
						case 
							when @inout_status_id is null then null
							-- входящие
							when @inout_status_id = -10 then th.d_add
						end,

					is_auditor = 
						case
							when exists(select 1 from tasks_themes_mols where theme_id = t.theme_id and mol_id = @mol_id) then 1
						end,

					is_executor = 
						case 
							when tm.id is not null and ts.is_working = 1 then 1 
						end,
								
					is_participant = 
						case 
							when exists(select 1 from tasks_mols where task_id = t.task_id and mol_id = @mol_id and role_id = 2) then 1
						end,

					is_overdue = 
						case 
							when ts.is_working = 1 and t.d_deadline < @today then 1
						end
				from <tasks_cache> t
					join tasks_statuses ts on ts.status_id = t.status_id
					left join tasks_mols tm on tm.task_id = t.task_id and tm.mol_id = @mol_id and tm.role_id = 1
					left join (
						select task_id, d_add = max(y.d_add) 
							from tasks_hists_mols x 
								join tasks_hists y on y.hist_id = x.hist_id
							where x.mol_id = @mol_id
								and x.d_read is null
						group by task_id
					) th on th.task_id = t.task_id
				', '<tasks_cache>', @tasks_cache)
				
			exec sp_executesql @sql, N'
				@mol_id int,
				@inout_status_id int,
				@today date
				',
				@mol_id, @inout_status_id, @today

		end -- if
end
go
