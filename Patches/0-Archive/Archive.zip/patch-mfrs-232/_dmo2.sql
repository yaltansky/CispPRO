delete from app_registry where registry_id = 'MfrCreateJobsInfoLimitDays'

INSERT INTO APP_REGISTRY(REGISTRY_ID, VAL_NUMBER, VAL_DATE, VAL_STRING)
VALUES ('MfrCreateJobsInfoLimitDays', 7, null, null)
GO
