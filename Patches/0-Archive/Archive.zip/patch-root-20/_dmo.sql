update objs_types 
set url = 
    case
        when type = 'inv' then '/finance/lgs/invoices'
        when type = 'invpay' then '/finance/lgs/invoices-pays'
    end
where type in ('inv', 'invpay')
GO