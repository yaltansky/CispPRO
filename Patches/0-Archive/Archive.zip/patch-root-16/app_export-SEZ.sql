-- dbcontext: CISP_SEZ
	if db_name() not in ('CISP_SEZ', 'CISP2')
		begin
			raiserror('This procedure is implemented only in CISP_SEZ', 16, 1)
			return
		end
		if object_id('app_export') is not null drop proc app_export
go
/***
  truncate table app_exports
  declare @group_id uniqueidentifier = newid()
  insert into app_exports(group_id, file_name, folder_id, obj_type, mol_id) values 
    (@group_id, 'Приходование материалов', 69934, 'SD', 1000),
    (@group_id, 'Выдача материалов', 69933, 'MFTRF', 1000)
  exec app_export @group_id
***/
go
create proc app_export
  @group_id uniqueidentifier
as
begin
	set nocount on;

  -- build xml
		declare c_exports cursor local read_only for 
			select export_id from app_exports where group_id = @group_id
		
		declare @export_id int
		
		open c_exports; fetch next from c_exports into @export_id
			while (@@fetch_status != -1)
			begin
				if (@@fetch_status != -2) exec app_export;2 @export_id
				fetch next from c_exports into @export_id
			end
		close c_exports; deallocate c_exports

  -- results
    select * from app_exports where group_id = @group_id
end
go
create proc app_export;2
  @export_id int
as
begin
	set nocount on;

  -- параметры
    declare
      @date_from date,
      @date_to date,
      @folder_id int,
      @obj_type varchar(20)

      select
        @date_from = d_from,
        @date_to = d_to,
        @folder_id = folder_id,
        @obj_type = obj_type
      from app_exports
      where export_id = @export_id 

    declare @result table(data xml)

  -- материалы: поступление на склад
    if (@obj_type = 'SD') 
      insert into @result
      exec app_export;20 @export_id, @date_from, @date_to, @folder_id

  -- материалы: выдача в производство
    if (@obj_type = 'MFTRF') 
      insert into @result
      exec app_export;30 @export_id, @date_from, @date_to, @folder_id

  -- сменные задания
    if (@obj_type = 'MFJ') 
      insert into @result
      exec app_export;40 @export_id, @date_from, @date_to, @folder_id

  -- табельное время
    if (@obj_type = 'MFW') 
      insert into @result
      exec app_export;50 @export_id, @date_from, @date_to, @folder_id

  -- save result
    update app_exports set data = (select top 1 data from @result)
    where export_id = @export_id
end
go
-- материалы: поступление на склад
create procedure app_export;20
  @export_id int,
  @date_from date = null,
  @date_to date = null,
  @folder_id int = null
as
begin
  declare @subjectId int = 127
  declare @subjectPrefix varchar(10) = concat(@subjectId, '-')
  declare @objs app_pkids

  -- tables
    create table #docs (
      doc_id int primary key,
      d_doc datetime,
      number varchar(50),
      note varchar(max),
      agent_name varchar(500),
      agent_inn varchar(50),
      d_doc_ext datetime,
      mol_to_id int,
      mol_to_name varchar(255),
      mol_to_extern_id varchar(100),
      acc_register_name varchar(255),
      acc_register_note varchar(max)
      )
    create table #docs_details (
      doc_id int,
      product_id int,
      item_id varchar(32),
      item_name varchar(500),
      mfr_number varchar(50),
      unit_name varchar(20),
      quantity float,
      sum_pc float,
      sum_pct float
      )

  -- @objs
    if (@folder_id is not null) begin
      insert into @objs
      select obj_id
      from objs_folders_details fd
        join sdocs sd on sd.doc_id = fd.obj_id and sd.type_id = 9
      where (folder_id = @folder_id)
        and obj_type = 'SD'

    end else begin
      insert into @objs
        select doc_id from sdocs
        where (type_id = 9) and
            (d_doc between isnull(@date_from,d_doc) and isnull(@date_to, d_doc))
    end

  -- список документов
    insert into #docs(
      doc_id, d_doc, number, note, agent_name, agent_inn, d_doc_ext, mol_to_id, mol_to_name, mol_to_extern_id, acc_register_name, acc_register_note
      )
    select
        h.doc_id, h.d_doc, h.number, h.note, agent_name = a.name, agent_inn = a.inn, h.d_doc_ext,
        h.mol_to_id,
        mol_to_name = concat(m.surname, ' ' + m.name1, ' ' + m.name2),
        mol_to_extern_id = m.tab_number,
        acc_register_name = r.name,
        acc_register_note = r.note
      from
        sdocs h
          left join agents a on (h.agent_id = a.agent_id)
          left join mols m on (h.mol_to_id = m.mol_id)
          left join accounts_registers r on (h.acc_register_id = r.acc_register_id)
          -- фильтр по документам
          join @objs f on (f.id = h.doc_id)

  -- табличная часть
    insert into #docs_details(
      doc_id, product_id, item_id, item_name, mfr_number, unit_name, quantity, sum_pc, sum_pct)
    select
        h.doc_id, p.product_id, e.item_id, item_name = p.name, d.mfr_number,
        unit_name = u.name, d.quantity, sum_pc = d.value_pure, sum_pct = d.value_rur
      from
        #docs h
          join sdocs_products d on (h.doc_id = d.doc_id)
          join products p on (d.product_id = p.product_id)
          left join (
            select e.product_id, item_id = max(substring(extern_id, len(@subjectPrefix) + 1, 50))
              from (
                select product_id, extern_id = ltrim(rtrim(extern_id)) from mfr_replications_products where extern_id like (@subjectPrefix + '%')
              ) e
              group by e.product_id
          ) e on (p.product_id = e.product_id)
          join products_units u on (d.unit_id = u.unit_id)

    -- залечим ITEM_ID из названия
    update d set d.item_id = substring(d.item_name, 2, charindex(']', d.item_name) - 2)
      from #docs_details d
      where
        (d.item_id is null) and
        (left(d.item_name, 1) = '[')

    -- исправим названия
    update d set
        d.item_id   = case when (left(d.item_id, 1) = 'm')
                        then replace(d.item_id, 'm', '')
                        else d.item_id
                      end,
        d.item_name = replace(d.item_name, '[' + d.item_id + '] ', '')
      from #docs_details d
      where (d.item_id is not null)

  -- выгрузим в xml
  select
    (
    select
        [@Источник]     = db_name(),
        [@Организация]  = 'СЭЗ',
        [@Агент]        = 'CISP',
        [@ВерсияАгента] = '1',
        [@Запрос]       = @export_id,
        [@Папка]        = convert(varchar(20), @folder_id, 104),
        (-- документы
         select (
           select
               [@ДокументКод]        = h.doc_id,
               [@ДокументДата]       = convert(varchar(10), h.d_doc, 104),
               [@ДокументНомер]      = h.number,
               [@ДокументТип]        = 'Поступление материала на склад',
               [@ДокументПримечание] = h.note,
               [@Клиент]             = h.agent_name,
               [@КлиентИНН]          = h.agent_inn,
               [@КлиентДата]         = convert(varchar(10), h.d_doc_ext, 104),
               [@Кладовщик]          = h.mol_to_name,
               [@КладовщикТаб]       = h.mol_to_extern_id,
               [@РазделительКод]     = h.acc_register_name,
               [@РазделительПрим]    = h.acc_register_note,
               (-- табличная часть
                select (
                  select
                      [@ProductId]    = d.product_id,
                      [@Код]          = d.item_id,
                      [@Наименование] = d.item_name,
                      [@Заказ]        = d.mfr_number,
                      [@ЕдИзм]        = d.unit_name,
                      [@Количество]   = cast(d.quantity as decimal(19,6)),
                      [@СуммаБНДС]    = cast(d.sum_pc as decimal(19,6)),
                      [@СуммаСНДС]    = cast(d.sum_pct as decimal(19,6))
                    from #docs_details d
                    where (h.doc_id = d.doc_id)
                    for xml path('Строка'), type
                ) for xml path('Строки'), type
               )
             from #docs h
             for xml path('Документ'), type
         ) for xml path('Документы'), type
        )
      for xml path('Сообщение')
    )

  --
  exec drop_temp_table '#docs,#docs_details'
end
go
-- материалы: выдача в производство
create procedure app_export;30
  @export_id int,
  @date_from date = null,
  @date_to date = null,
  @folder_id int = null
as
begin
  declare @subjectId int = 127
  declare @subjectPrefix varchar(10) = concat(@subjectId, '-')
  declare @objs app_pkids

  -- tables
    create table #docs (
      doc_id int,
      d_doc datetime,
      number varchar(50),
      division_from varchar(50),
      mol_id int,
      mol_name varchar(255),
      mol_extern_id varchar(100),
      division_to varchar(50),
      mol_to_id int,
      mol_to_name varchar(255),
      mol_to_extern_id varchar(100),
      acc_register_name varchar(255),
      acc_register_note varchar(max),
      note varchar(max)
      )
    create table #docs_details (
      doc_id int,
      product_id int,
      item_id varchar(32),
      item_name varchar(500),
      mfr_doc_no varchar(50),
      unit_name varchar(20),
      quantity float
      )

  -- @objs
    if (@folder_id is not null) begin
      insert into @objs
      select obj_id
      from objs_folders_details
      where (folder_id = @folder_id)
        and obj_type = 'MFTRF'
    end else begin
      insert into @objs
        select obj_id = doc_id
        from sdocs
        where (type_id = 12)
          and (d_doc between isnull(@date_from,d_doc) and isnull(@date_to, d_doc))
    end

  -- список документов
    insert into #docs(
      doc_id, d_doc, number, division_from, mol_id, mol_name, mol_extern_id, division_to, mol_to_id, mol_to_name, mol_to_extern_id, note, acc_register_name, acc_register_note)
    select
        h.doc_id, h.d_doc, h.number,
        division_from = p1.name,
        mol_id        = m1.mol_id,
        mol_name      = concat(m1.surname, ' ' + m1.name1, ' ' + m1.name2),
        mol_extern_id = m1.tab_number,
        division_to   = p2.name,
        mol_to_id     = m2.mol_id,
        mol_to_name   = concat(m2.surname, ' ' + m2.name1, ' ' + m2.name2),
        mol_to_extern_id = m2.tab_number,
        note          = h.note,
        acc_register_name = r.name,
        acc_register_note = r.note
      from
        sdocs h
          left join mfr_places p1 on (h.place_id = p1.place_id)
          left join mols m1 on (h.mol_id = m1.mol_id)
          left join mfr_places p2 on (h.place_to_id = p2.place_id)
          left join mols m2 on (h.mol_to_id = m2.mol_id)
          left join accounts_registers r on (h.acc_register_id = r.acc_register_id)
          -- фильтр по документам
          join @objs f on (h.doc_id = f.id)
      where
        (h.extern_id is null)

  -- табличная часть
    insert into #docs_details (doc_id, product_id, item_id, item_name, mfr_doc_no, unit_name, quantity)
      select h.doc_id, p.product_id, e.item_id, item_name = ltrim(rtrim(p.name)), mfr_doc_no = d.mfr_number, unit_name = u.name, d.quantity
        from
          #docs h
            join sdocs_products d on (h.doc_id = d.doc_id)
            join products p on (d.product_id = p.product_id)
            left join (
              select e.product_id, item_id = max(substring(extern_id, len(@subjectPrefix) + 1, 50))
                from (
                  select product_id, extern_id = ltrim(rtrim(extern_id)) from mfr_replications_products where extern_id like (@subjectPrefix + '%')
                ) e
                group by e.product_id
            ) e on (p.product_id = e.product_id)
            join products_units u on (d.unit_id = u.unit_id)

  -- залечим ITEM_ID из названия
    update d set d.item_id = substring(d.item_name, 2, charindex(']', d.item_name) - 2)
      from #docs_details d
      where
        (d.item_id is null) and
        (left(d.item_name, 1) = '[')

  -- исправим названия
    update d set
        d.item_id   = case when (left(d.item_id, 1) = 'm')
                        then replace(d.item_id, 'm', '')
                        else d.item_id
                      end,
        d.item_name = replace(d.item_name, '[' + d.item_id + '] ', '')
      from #docs_details d
      where (d.item_id is not null)

  -- выгрузим в xml
  select
    (
    select
        [@Источник]     = db_name(),
        [@Организация]  = 'СЭЗ',
        [@Агент]        = 'CISP',
        [@ВерсияАгента] = '1',
        [@Запрос]       = @export_id,
        [@Папка]        = convert(varchar(20), @folder_id, 104),
        (-- документы
         select (
           select
               [@ДокументКод]     = h.doc_id,
               [@ДокументДата]    = convert(varchar(10), h.d_doc, 104),
               [@ДокументНомер]   = h.number,
               [@ДокументТип]     = 'Выдача материала в производство',
               [@Примечание]      = h.note,
               [@ПодразделениеИз] = h.division_from,
               [@КладовщикИз]     = h.mol_name,
               [@КладовщикИзТаб]  = h.mol_extern_id,
               [@ПодразделениеВ]  = h.division_to,
               [@КладовщикВ]      = h.mol_to_name,
               [@КладовщикВТаб]   = h.mol_to_extern_id,
               [@РазделительКод]  = h.acc_register_name,
               [@РазделительПрим] = h.acc_register_note,
               (-- табличная часть
                select (
                  select
                      [@ProductId]      = d.product_id,
                      [@Код]            = d.item_id,
                      [@Наименование]   = d.item_name,
                      [@Заказ]          = d.mfr_doc_no,
                      [@ЕдИзм]          = d.unit_name,
                      [@КоличествоФакт] = cast(d.quantity as decimal(19,6))
                    from #docs_details d
                    where (h.doc_id = d.doc_id)
                    for xml path('Строка'), type
                ) for xml path('Строки'), type
               )
             from #docs h
             for xml path('Документ'), type
         ) for xml path('Документы'), type
        )
      for xml path('Сообщение')
    )

  --
  exec drop_temp_table '#docs,#docs_details'
end
go
-- сменные задания
create procedure app_export;40
  @export_id int,
  @date_from date = null,
  @date_to date = null,
  @folder_id int = null
as
begin
  declare @subjectId int = 127
  declare @subjectPrefix varchar(10) = concat(@subjectId, '-')
  declare @objs app_pkids

  -- tables
    create table #docs (
      plan_job_id int,
      d_doc datetime,
      d_closed datetime,
      number varchar(100),
      place_no varchar(100),
      place_to_no varchar(100)
    )
    create table #docs_details (
      plan_job_id int,
      detail_id int,
      mfr_doc_no varchar(50),
      product_id int,
      parent_id varchar(32),
      parent_name varchar(500),
      item_id varchar(32),
      item_name varchar(500),
      content_id int,
      position_id int,
      packid int,
      docid varchar(50),
      productid varchar(50),
      entry_id varchar(255),
      variant_number int,
      oper_number int,
      oper_name varchar(100),
      operkey varchar(20),
      opercode varchar(20),
      resource_name varchar(255),
      unit_name varchar(20),
      plan_q float,
      fact_q float
    )
    create table #docs_mols (
      rowid int identity(1,1),
      detail_id int,
      d_doc datetime,
      wk_shift varchar(50),
      mol_id int,
      mol_name varchar(255),
      extern_id varchar(100),
      is_master int,
      fact_q float,
      plan_duration_wk_name varchar(10),
      plan_duration_wk float
    )

  -- @objs
    if (@folder_id is not null) begin
      insert into @objs
      select obj_id
      from objs_folders_details
      where (folder_id = @folder_id)
        and obj_type = 'MFJ'
    end else begin
      insert into @objs
        select obj_id = plan_job_id
        from mfr_plans_jobs h
        where (type_id = 1)
          and (h.extern_id is null)
          and (d_doc between isnull(@date_from,d_doc) and isnull(@date_to, d_doc))
    end

  -- список документов
    insert into #docs (plan_job_id, d_doc, d_closed, number, place_no, place_to_no)
      select h.plan_job_id, h.d_doc, h.d_closed, h.number, place_no = p1.name, place_to_no = p2.name
        from
          mfr_plans_jobs h
            join mfr_places p1 on (h.place_id = p1.place_id)
            left join mfr_places p2 on (h.place_to_id = p2.place_id)
            -- фильтр по документам
            join @objs f on (h.plan_job_id = f.id)
        where
          (h.type_id = 1) and     -- тип "Сменное задание"
          (h.extern_id is null)   -- создано в КИСП

  -- табличная часть
    insert into #docs_details (plan_job_id, detail_id, mfr_doc_no, product_id, parent_id, parent_name, item_id, item_name, content_id, packid, docid, productid, entry_id, variant_number, oper_number, oper_name, operkey, opercode, resource_name, unit_name, plan_q, fact_q)
      select
          d.plan_job_id, detail_id = d.id, mfr_doc_no = h1.number, p1.product_id,
          parent_id = e2.item_id, item_name = ltrim(rtrim(p2.name)),
          e1.item_id, item_name = ltrim(rtrim(p1.name)),
          d.content_id, c1.packid, c1.docid, c1.productid, entry_id = null, --c1.entryid,
          variant_number = v.route_number, d.oper_number, d.oper_name, o.operkey, opercode = isnull(o.extern_id, s.opercode), resource_name = r.name,
          c.unit_name, d.plan_q, d.fact_q
        from
          #docs h
            join mfr_plans_jobs_details d on (h.plan_job_id = d.plan_job_id)
            left join sdocs h1 on (d.mfr_doc_id = h1.doc_id)
            left join projects_resources r on (d.resource_id = r.resource_id)
            left join sdocs_mfr_contents c on (d.content_id = c.content_id)
            join products p1 on (d.item_id = p1.product_id)
            left join (
              select e.product_id, item_id = right(e.extern_id, len(e.extern_id) - charindex('-', e.extern_id))
                from mfr_replications_products e
                group by e.product_id, right(e.extern_id, len(e.extern_id) - charindex('-', e.extern_id))
            ) e1 on (p1.product_id = e1.product_id)
            left join mfr_drafts_pdm v on (c.draft_id = v.draft_id) and
                                          (v.route_number is not null)
            left join sdocs_mfr_contents c2 on (c.mfr_doc_id = c2.mfr_doc_id) and
                                                (c.product_id = c2.product_id) and
                                                (c.parent_id = c2.child_id)
            left join products p2 on (c2.item_id = p2.product_id)
            left join (
              select e.product_id, item_id = right(e.extern_id, len(e.extern_id) - charindex('-', e.extern_id))
                from mfr_replications_products e
                group by e.product_id, right(e.extern_id, len(e.extern_id) - charindex('-', e.extern_id))
            ) e2 on (p2.product_id = e2.product_id)
            left join sdocs_mfr_drafts f on (c.draft_id = f.draft_id)
            left join sdocs_mfr_drafts_opers o on (d.oper_number = o.number) and
                                                  (f.draft_id = o.draft_id)
            -- код операции по имени из шлюза
            left join (
              select opercode = max(o.opercode), o.opername
                from
                  cisp_gate..packs p
                    join cisp_gate..doc_mfr_opers o on (p.packid = o.packid)
                where (p.channelname = 'sez.mfrcontents')
                group by o.opername
            ) s on (d.oper_name = s.opername)
            -- id узла из шлюза
            left join cisp_gate..doc_mfr_contents c1 on (f.extern_id = c1.childid) 
            left join cisp_gate..packs k1 on (c1.packid = k1.packid) and
                                              (k1.channelname = 'sez.mfrcontents')
        where (nullif(d.fact_q, 0.0) is not null)
        order by d.plan_job_id, d.item_id, h1.number, o.operkey
  -- табличная часть, получим entry_id
  -- ■ position_id
    update d set d.position_id = isnull(c.position_id, 1)
      from
        #docs_details d
          left join (
            select
                c.content_id,
                position_id = row_number() over (partition by c.mfr_doc_id, c.product_id, c.item_id order by c.content_id)
              from
                sdocs_mfr_contents c
                  inner join (
                    select c.mfr_doc_id, c.product_id, c.item_id
                      from sdocs_mfr_contents c
                      where (c.is_buy = 0)
                      group by c.mfr_doc_id, c.product_id, c.item_id
                      having (count(*) > 1)
                  ) s on (c.mfr_doc_id = s.mfr_doc_id) and
                          (c.product_id = s.product_id) and
                          (c.item_id = s.item_id)
          ) c on (d.content_id = c.content_id)
  -- ■ entry_id
    update d set d.entry_id = c.entryid
      from
        #docs_details d
          inner join (
            select
                c.packid, c.docid, c.productid, c.itemid, c.entryid,
                positionid = row_number() over (partition by c.packid, c.docid, c.productid, c.itemid order by c.childid)
              from
                cisp_gate..packs p
                  inner join cisp_gate..doc_mfr_contents c on (p.packid = c.packid)
                  inner join (
                    select c.packid, c.docid, c.productid, c.itemid
                      from
                        cisp_gate..packs p
                          inner join cisp_gate..doc_mfr_contents c on (p.packid = c.packid)
                      where
                        (p.channelname = 'sez.mfrcontents') and
                        (left(c.itemid, 1) != 'm')
                      group by c.packid, c.docid, c.productid, c.itemid
                      having (count(*) > 1)
                  ) s on (c.packid = s.packid) and
                          (c.docid = s.docid) and
                          (c.productid = s.productid) and
                          (c.itemid = s.itemid)
              where
                (p.channelname = 'sez.mfrcontents') and
                (left(c.itemid, 1) != 'm')
          ) c on (d.packid = c.packid) and
                  (d.docid = c.docid) and
                  (d.productid = c.productid) and
                  (d.item_id = c.itemid) and
                  (d.position_id = c.positionid)

  -- исполнители
    insert into #docs_mols (detail_id, d_doc, wk_shift, mol_id, mol_name, extern_id, is_master, fact_q, plan_duration_wk_name, plan_duration_wk)
      select
          d.detail_id,
          e.d_doc,
          e.wk_shift,
          e.mol_id,
          mol_name  = m.surname +
                        case when (nullif(m.name1, '') is null) then '' else ' ' + m.name1 end +
                        case when (nullif(m.name2, '') is null) then '' else ' ' + m.name2 end,
          extern_id = m.tab_number,
          is_master = -- 1 бригадир, 0 исполнитель
                      case
                        when
                          exists(
                            select 1
                              from
                                -- строки табеля
                                mfr_wk_sheets_details wd
                                  -- связанные задания
                                  inner join mfr_wk_sheets_jobs wj on (wd.wk_sheet_id = wj.wk_sheet_id)
                                  -- табели
                                  inner join mfr_wk_sheets wk on (wd.wk_sheet_id = wk.wk_sheet_id)
                              where
                                (wj.detail_id = d.detail_id) and
                                (wd.mol_id = e.mol_id) and
                                (wk.d_doc = e.d_doc) and
                                (wd.has_childs = 1)
                          )
                        then 1 else 0
                      end,
          e.fact_q,
          plan_duration_wk_name = u.name,
          e.plan_duration_wk
        from
          #docs_details d
            inner join mfr_plans_jobs_executors e on (d.detail_id = e.detail_id)
            left join projects_durations u on (e.plan_duration_wk_id = u.duration_id)
            inner join mols m on (e.mol_id = m.mol_id)

  -- удалим пустые документы
    delete h
      from #docs h
            left join #docs_details d on (h.plan_job_id = d.plan_job_id)
      where (d.plan_job_id is null)

  -- выгрузим в xml
    select
      (
      select
          [@Источник]     = db_name(),
          [@Организация]  = 'СЭЗ',
          [@Агент]        = 'CISP',
          [@ВерсияАгента] = '1',
          [@Запрос]       = @export_id,
          [@Папка]        = convert(varchar(20), @folder_id, 104),
          [@Тест]         = 'нет',
          (-- сменные задания
          select (
            select
                [@ДокументКод]     = h.plan_job_id,
                [@ДокументДата]    = convert(varchar(10), h.d_doc, 104),
                [@ДатаЗакрытия]    = convert(varchar(10), h.d_closed, 104),
                [@ДокументНомер]   = h.number,
                [@ДокументТип]     = 'сменное задание',
                [@ПодразделениеИз] = h.place_no,
                [@ПодразделениеВ]  = h.place_to_no,
                (-- табличная часть
                  select (
                    select
                        --[@Нпп]            = oper_number,
                        [@DETAIL_ID]      = d.detail_id,
                        [@Заказ]          = d.mfr_doc_no,
                        [@ParentId]       = d.parent_id,
                        [@ParentName]     = d.parent_name,
                        [@ProductId]      = d.product_id,
                        [@Код]            = d.item_id,
                        [@Наименование]   = d.item_name,
                        [@EntryId]        = d.entry_id,
                        [@ВариантТП]      = d.variant_number,
                        [@ОперацияНомер]  = d.opercode,
                        [@Операция]       = d.oper_name,
                        [@ОперацияКод]    = d.operkey,
                        [@Оборудование]   = d.resource_name,
                        [@ЕдИзм]          = d.unit_name,
                        [@КоличествоПлан] = cast(d.plan_q as decimal(19,6)),
                        [@КоличествоФакт] = cast(d.fact_q as decimal(19,6)),
                        (-- исполнители
                        select (
                          select
                              [@ДатаСтроки]     = convert(varchar(10), isnull(m.d_doc, h.d_doc), 104),
                              [@Смена]          = m.wk_shift,
                              [@ИсполнительКод] = m.mol_id,
                              [@Исполнитель]    = m.mol_name,
                              [@ТабельныйНомер] = m.extern_id,
                              [@Бригадир]       = m.is_master,
                              [@КоличествоФакт] = cast(m.fact_q as decimal(19,6)),
                              [@ЕдИзм]          = m.plan_duration_wk_name,
                              [@Длительность]   = cast(m.plan_duration_wk as decimal(19,6))
                            from #docs_mols m
                                    -- оставляем только первого исполнителя
                                    --inner join (
                                    --  select detail_id, rowid = min(rowid), plan_duration_wk = sum(plan_duration_wk)
                                    --    from #docs_mols
                                    --    group by detail_id
                                    --) f on (m.rowid = f.rowid)
                            where (d.detail_id = m.detail_id)
                            for xml path('Исполнитель'), type
                        ) for xml path('Исполнители'), type
                        )
                      from #docs_details d
                      where (h.plan_job_id = d.plan_job_id)
                      for xml path('Строка'), type
                  ) for xml path('Строки'), type
                )
              from #docs h
              for xml path('Документ'), type
          ) for xml path('Документы'), type
          )
        for xml path('Сообщение')
      )

  --
  exec drop_temp_table '#docs,#docs_details,#docs_mols'
end
go
-- табельное время
create procedure app_export;50
  @export_id int,
  @date_from date = null,
  @date_to date = null,
  @folder_id int = null
as
begin
  declare @subjectId int = 37
  declare @subjectPrefix varchar(10) = concat(@subjectId, '-')
  declare @objs app_pkids

  -- tables
    create table #data (
      fact_date datetime,
      full_name varchar(400),
      dep_name varchar(255),
      dep_name_full varchar(255),
      mfr_no varchar(150),
      fact_hour decimal(19,3)
    )

  -- @objs
    if (@folder_id is not null) begin
      insert into @objs
        select obj_id
        from objs_folders_details
        where (folder_id = @folder_id)
            and obj_type = 'MFW'
    end else begin
      insert into @objs
        select wk_sheet_id
        from mfr_wk_sheets
        where d_doc between isnull(@date_from, d_doc) and isnull(@date_to, d_doc)
    end

  -- реестр данных
    insert into #data (fact_date, full_name, dep_name, dep_name_full, mfr_no, fact_hour)
      select fact_date, full_name, dep_name, dep_name_full, mfr_no, sum(fact_hour)
      from (
        select
            fact_date     = f.d_doc,
            full_name     = ltrim(rtrim(m.surname + ' ' + isnull(m.name1, '') + ' ' + isnull(m.name2, ''))),
            dep_name      = left(isnull(p.name, '---'), 3),
            dep_name_full = p.full_name,
            mfr_no        = h1.number,
            fact_hour     = f.duration_wk * dur.factor / dur_h.factor
        from
            mfr_wk_sheets h
                join mfr_wk_sheets_jobs f on (h.wk_sheet_id = f.wk_sheet_id)
                    join mfr_plans_jobs_details jd on jd.id = f.detail_id
                        join sdocs h1 on (jd.mfr_doc_id = h1.doc_id)
                    join projects_durations dur on dur.duration_id = f.duration_wk_id
                    join projects_durations dur_h on dur_h.duration_id = 2
                join mols m on (f.mol_id = m.mol_id)
                left join (
                    select mol_id, place_id = max(place_id) from mfr_places_mols group by mol_id
                ) e on (m.mol_id = e.mol_id)
                left join mfr_places p on (e.place_id = p.place_id)
                -- фильтр по документам
                join @objs o on (o.id = h.wk_sheet_id)
        ) x
      group by fact_date, full_name, dep_name, dep_name_full, mfr_no

  -- выгрузим в xml
    select
      (
      select
          [@Источник]     = db_name(),
          [@Организация]  = 'ЛЭЗ',
          [@Агент]        = 'CISP',
          [@ВерсияАгента] = '1',
          [@Запрос]       = @export_id,
          [@Папка]        = convert(varchar(20), @folder_id, 104),
          [@Тест]         = 'нет',
          (-- исполнители
            select
                [Дата]            = convert(varchar(10), h.fact_date, 104),
                [Исполнитель]     = h.full_name,
                [Заказ]           = h.mfr_no,
                [ОтработаноЧасов] = h.fact_hour
              from #data h
              for xml path('ИсполнителиГОСЗаказов'), type
          )
        for xml path('Корневой')
      )

  --
  exec drop_temp_table '#data'
end