-- dbcontext: CISP
	if db_name() not in ('CISP', 'CISP2')
		begin
			raiserror('This procedure is implemented only in CISP', 16, 1)
			return
		end
		if object_id('app_export') is not null drop proc app_export
go
/***
  truncate table app_exports
  declare @group_id uniqueidentifier = newid()
  insert into app_exports(group_id, file_name, folder_id, obj_type, mol_id) values 
    (@group_id, 'Табельное время', 71074, 'MFW', 1000)
  exec app_export @group_id
***/
go
create proc app_export
  @group_id uniqueidentifier
as
begin
	set nocount on;

  -- build xml
		declare c_exports cursor local read_only for 
			select export_id from app_exports where group_id = @group_id
		
		declare @export_id int
		
		open c_exports; fetch next from c_exports into @export_id
			while (@@fetch_status != -1)
			begin
				if (@@fetch_status != -2) exec app_export;2 @export_id
				fetch next from c_exports into @export_id
			end
		close c_exports; deallocate c_exports

  -- results
    select * from app_exports where group_id = @group_id
end
go
create proc app_export;2
  @export_id int
as
begin
	set nocount on;

  -- параметры
    declare
      @date_from date,
      @date_to date,
      @folder_id int,
      @obj_type varchar(20)

      select
        @date_from = d_from,
        @date_to = d_to,
        @folder_id = folder_id,
        @obj_type = obj_type
      from app_exports
      where export_id = @export_id 

    declare @result table(data xml)

  -- табельное время
    if (@obj_type = 'MFW') 
      insert into @result
      exec app_export;50 @export_id, @date_from, @date_to, @folder_id

  -- save result
    update app_exports set data = (select top 1 data from @result)
    where export_id = @export_id
end
go
-- табельное время
create procedure app_export;50
  @export_id int,
  @date_from date = null,
  @date_to date = null,
  @folder_id int = null
as
begin
  declare @subjectId int = 37
  declare @subjectPrefix varchar(10) = concat(@subjectId, '-')
  declare @objs app_pkids

  -- tables
    create table #data (
      fact_date datetime,
      full_name varchar(400),
      dep_name varchar(255),
      dep_name_full varchar(255),
      mfr_no varchar(150),
      fact_hour decimal(19,3)
    )

  -- @objs
    if (@folder_id is not null) begin
      insert into @objs
      select obj_id
      from objs_folders_details
      where (folder_id = @folder_id)
        and obj_type = 'MFW'
    end 
    
    else begin
      insert into @objs
        select wk_sheet_id
        from mfr_wk_sheets
        where d_doc between isnull(@date_from, d_doc) and isnull(@date_to, d_doc)
    end

  -- реестр данных
    insert into #data (fact_date, full_name, dep_name, dep_name_full, mfr_no, fact_hour)
      select fact_date, full_name, dep_name, dep_name_full, mfr_no, sum(fact_hour)
      from (
        select
            fact_date     = f.d_doc,
            full_name     = ltrim(rtrim(m.surname + ' ' + isnull(m.name1, '') + ' ' + isnull(m.name2, ''))),
            dep_name      = left(isnull(p.name, '---'), 3),
            dep_name_full = p.full_name,
            mfr_no        = h1.number,
            fact_hour     = f.duration_wk * dur.factor / dur_h.factor
        from
            mfr_wk_sheets h
                join mfr_wk_sheets_jobs f on (h.wk_sheet_id = f.wk_sheet_id)
                    join mfr_plans_jobs_details jd on jd.id = f.detail_id
                        join sdocs h1 on (jd.mfr_doc_id = h1.doc_id)
                    join projects_durations dur on dur.duration_id = f.duration_wk_id
                    join projects_durations dur_h on dur_h.duration_id = 2
                join mols m on (f.mol_id = m.mol_id)
                left join (
                    select mol_id, place_id = max(place_id) from mfr_places_mols group by mol_id
                ) e on (m.mol_id = e.mol_id)
                left join mfr_places p on (e.place_id = p.place_id)
                -- фильтр по документам
                join @objs o on (o.id = h.wk_sheet_id)
        ) x
      group by fact_date, full_name, dep_name, dep_name_full, mfr_no

  -- выгрузим в xml
    select
      (
      select
          [@Источник]     = db_name(),
          [@Организация]  = 'ЛЭЗ',
          [@Агент]        = 'CISP',
          [@ВерсияАгента] = '1',
          [@Запрос]       = @export_id,
          [@Папка]        = convert(varchar(20), @folder_id, 104),
          [@Тест]         = 'нет',
          (-- исполнители
            select
                [Дата]            = convert(varchar(10), h.fact_date, 104),
                [Исполнитель]     = h.full_name,
                [Заказ]           = h.mfr_no,
                [ОтработаноЧасов] = h.fact_hour
              from #data h
              for xml path('ИсполнителиГОСЗаказов'), type
          )
        for xml path('Корневой')
      )

  --
  exec drop_temp_table '#data'
end