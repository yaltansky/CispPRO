﻿if object_id('app_checkdb') is not null drop proc app_checkdb
go
create proc app_checkdb
as
begin
	
	declare @proc_name varchar(50) = object_name(@@procid)
	declare @message varchar(max)

	if (	select is_broker_enabled from sys.databases where name = 'CISP') = 0
	begin
		set @message = 'ERROR: в базе данных CISP отключена опция IS_BROKER_ENABLED.'

		insert into trace_log(trace_name, note, date_start, date_end, is_alert)
		values(@proc_name, @message, getdate(), getdate(), 1)

		print @message
	end

	if exists(
		select 1
		from findocs_details	 d
			join findocs f on f.findoc_id = d.findoc_id
		group by f.findoc_id, f.value_ccy
		having cast(f.value_ccy - sum(d.value_ccy) as decimal) <> 0
		)
	begin
		set @message = 'ERROR: есть несоответствия findocs + findocs_details.'
		
		insert into trace_log(trace_name, note, date_start, date_end, is_alert)
		values(@proc_name, @message, getdate(), getdate(), 1)

		print @message
	end

	-- if not exists(
	-- 	select 1 from sys.databases x where name = db_name() and is_broker_enabled = 1
	-- 	)
	-- begin
	-- 	set @message = 'ERROR: необходимо установить опцию базы "Broker enabled" в true.'

	-- 	insert into trace_log(trace_name, note, date_start, date_end, is_alert)
	-- 	values(@proc_name, @message, getdate(), getdate(), 1)

	-- 	print @message
	-- end

	truncate table trace_log

	delete from objs_folders_details
	where folder_id in (select folder_id from objs_folders where keyword = 'buffer')

	declare @today date = dbo.today()
	delete from queues where datediff(d, add_date, @today) > 2

end
go
