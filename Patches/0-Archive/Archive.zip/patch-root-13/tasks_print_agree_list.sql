if object_id('tasks_print_agree_list') is not null drop proc tasks_print_agree_list
go
create proc tasks_print_agree_list
	@task_id int
as
begin
  	set nocount on;

	declare @xml xml = (select reserved from tasks where task_id = @task_id)
    
	declare @handle_xml int
	exec sp_xml_preparedocument @handle_xml output, @xml
		
	select dbo.xml2json((
		select 
			t.task_id as TaskId, 
			TaskDate = format(t.add_date, 'dd.MM.yyyy'), 
			CrmManagerName = m.name,		 
			ProductFullName = ta1.attr_value,
			DocNumber = ta2.attr_value,
			MfrPlace = ta3.attr_value, 
			TransferPrice = ta4.attr_value,
			ApprovalListNo = (
				select ApprovalListNo
				from openxml (@handle_xml, '/ApprovalListData/ApprovalListNo', 2) with (ApprovalListNo varchar(500) 'text()')
				)
		from tasks t 
			left join mols m on t.author_id = m.mol_id
			left join (
				select task_id, attr_value from tasks_attrs where attr_name = 'FullName'
			) ta1 on t.task_id = ta1.task_id
			left join (
				select task_id, attr_value from tasks_attrs where attr_name = 'RegulatoryDocs'
			) ta2 on t.task_id = ta2.task_id
			left join (
				select task_id, attr_value from tasks_attrs where attr_name = 'MfrPlace'
			) ta3 on t.task_id = ta3.task_id
			left join (
				select task_id, attr_value from tasks_attrs where attr_name = 'TrfPrice'
			) ta4 on t.task_id = ta4.task_id 
		where t.task_id = @task_id for xml raw
	))

	exec sp_xml_removedocument @handle_xml
end
go
