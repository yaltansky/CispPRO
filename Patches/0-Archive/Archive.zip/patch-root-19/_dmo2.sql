IF DBO.COLUMN_ID('APP_REGISTRY.IS_SHARED') IS NULL
    ALTER TABLE APP_REGISTRY ADD IS_SHARED BIT
GO

update app_registry set name = registry_id where name is null
update app_registry set val_type = 'roles' where val_string like 'mfr.%'
update app_registry set note = 'Способ расчёта регистра материалов: strict - строгий поадресный учёт, jobsByDoc - товарные потоки связываются гибко по заказам, jobsAverage - товарные потоки связываются по среднему' where REGISTRY_ID = 'MfrProvidesCalcMode'

GO
