﻿if object_id('tiu_products_attrs') is not null drop trigger tiu_products_attrs
go
create trigger tiu_products_attrs on PRODUCTS_ATTRS
for insert, update
as
begin
	if update(attr_value)
	begin
		update products_attrs set attr_value_number = isnull(try_parse(attr_value as float using 'ru'), attr_value_number)
		where id in (
			select id from inserted
			union select id from deleted
			)
	end

	if update(attr_value_id)
	begin
		declare @table_list_attrs table(attr_id int primary key, value_type_list varchar(max), table_name varchar(100), key_id varchar(64))
			insert into @table_list_attrs(attr_id, value_type_list)
			select distinct pa.attr_id, pa.value_type_list
			from inserted i
				join prodmeta_attrs pa on pa.attr_id = i.attr_id
			where pa.value_type_list like 'table:%'

		declare @table_info varchar(200)
		update @table_list_attrs
		set @table_info = dbo.strtoken(value_type_list, ':', 2),
			table_name = dbo.strtoken(@table_info, '/', 1),
			key_id = dbo.strtoken(@table_info, '/', 2)

		declare c_attrs cursor local read_only for 
			select attr_id, table_name, key_id from @table_list_attrs
		
		declare @attr_id int, @table_name varchar(100), @key_id varchar(100)
		
		open c_attrs; fetch next from c_attrs into @attr_id, @table_name, @key_id
			while (@@fetch_status <> -1)
			begin
				if (@@fetch_status <> -2) 
				begin
					select * into #inserted_ti_products_attrs from inserted
					declare @sql nvarchar(max) = '
					update x set attr_value = xx.name
					from products_attrs x
						join #inserted_ti_products_attrs i on i.id = x.id
						join %table% xx on xx.%key_id% = x.attr_value_id
					where x.attr_id = %attr_id%
					'
					set @sql = replace(@sql, '%table%', @table_name)
					set @sql = replace(@sql, '%key_id%', @key_id)
					set @sql = replace(@sql, '%attr_id%', @attr_id)
					exec sp_executesql @sql
					exec drop_temp_table '#inserted_ti_products_attrs'
				end
				fetch next from c_attrs into @attr_id, @table_name, @key_id
			end
		close c_attrs; deallocate c_attrs
		
	end
end
GO
