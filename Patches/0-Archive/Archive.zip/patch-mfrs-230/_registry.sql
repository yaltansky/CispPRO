SELECT TOP 0 REGISTRY_ID, VAL_NUMBER, VAL_DATE, VAL_STRING INTO #REGISTRY FROM APP_REGISTRY

INSERT INTO #REGISTRY(REGISTRY_ID, VAL_NUMBER, VAL_DATE, VAL_STRING)
VALUES 
    ('DeveloperEmail', null, null, 'yaltansky@gmail.com'),
    ('SystemEmail', null, null, 'cisportal@ruselprom.ru'),
    ('CompanyMailHost', null, null, 'mail.ruselprom.ru'),
    ('HostName', null, null, 'cisp.ruselprom.ru'),
    ('CompanyDefaultHelpDeskAnalyzerId', 800, null, null),
    ('SqlProcTrace', 1, null, null),
    -- 
    ('MfrUseStaticPrice', 1, null, null),
    ('MfrCalcBalanceByDoc', 1, null, null),
    -- 
    ('AllowMfrCalcJobs', null, null, 'Mfr.Admin'),
    ('AllowMfrCalcProvides', null, null, 'Mfr.Admin,Mfr.Admin.Materials'),
    ('AllowMfrCalcOpersBase', null, null, 'Mfr.Admin'),
    ('AllowMfrCalcOpersPredict', null, null, 'Mfr.Admin'),
    ('AllowMfrCalcOpersPlan', null, null, 'Mfr.Admin'),
    ('AllowMfrCalcPlan', null, null, 'Mfr.Admin'),
    ('AllowMfrCalcSupplyPays', null, null, 'Mfr.Admin'),
    ('mfr_plan_qjobs_buffer_action:any', null, null, 'Mfr.Admin,Mfr.Jobs.Moderator'),
    ('mfr_plan_qjobs_buffer_action:CloseRows', null, null, 'Mfr.Admin,Mfr.Jobs.Moderator'),
    ('mfr_items_create_swaps', null, null, 'Mfr.Admin,Mfr.Admin.Materials,Mfr.Moderator.Materials'),
    ('mfr_plan_job_sign:any', null, null, 'Mfr.Admin,Mfr.Moderator,Mfr.Jobs.Moderator'),
    ('mfr_plan_jobs_buffer_action:any', null, null, 'Mfr.Admin,Mfr.Moderator,Mfr.Jobs.Moderator'),
    ('mfr_plan_jobs_buffer_action:BindStatus', null, null, 'Mfr.Admin'),
    ('mfr_plan_jobs_buffer_action:SplitByExecutorsDate', null, null, 'Mfr.Admin'),
    ('mfr_plan_jobs_buffer_action:CalcJobsRegister', null, null, 'Mfr.Admin,Mfr.Moderator'),
    ('mfr_items_buffer_action:any', null, null, 'Mfr.Moderator,Mfr.Moderator.Drafts,Mfr.Admin.Materials,Mfr.Moderator.Materials'),
    ('mfr_items_bind:any', null, null, 'Mfr.Moderator,Mfr.Moderator.Drafts,Mfr.Admin.Materials,Mfr.Moderator.Materials'),
    ('mfr_items_bind:admin', null, null, 'Admin,Mfr.Admin'),
    ('mfr_items_bind:superadmin', null, null, 'Admin'),
    ('mfr_items_bind.BindPdmOpers.MaxRows', 100, null, null),
    ('mfr_items_create_doctrfs', null, null, 'Mfr.Admin,Mfr.Moderator'),
    ('mfr_docs_trf_buffer_action:any', null, null, 'Mfr.Admin,Mfr.Admin.Materials,Mfr.Moderator,Mfr.Moderator.Materials'),
    ('mfr_docs_trf_buffer_action:admin', null, null, 'Mfr.Admin,Mfr.Admin.Materials,Mfr.Moderator,Mfr.Moderator.Materials'),
    ('invoices_calc_pays:any', null, null, 'Admin,Mfr.Admin,Mfr.Admin.Materials'),
    ('products_buffer_action:any', null, null, 'Admin,Mfr.Admin,Mfr.Admin.Materials,Products.Admin'),
    ('products_buffer_action:admin', null, null, 'Admin,Mfr.Admin,Mfr.Admin.Materials,Products.Admin')

DELETE X FROM APP_REGISTRY X
    JOIN #REGISTRY R ON R.REGISTRY_ID = X.REGISTRY_ID

INSERT INTO APP_REGISTRY(REGISTRY_ID, NAME, VAL_NUMBER, VAL_DATE, VAL_STRING, IS_DELETED)
SELECT REGISTRY_ID, REGISTRY_ID, VAL_NUMBER, VAL_DATE, VAL_STRING, 0
FROM #REGISTRY

EXEC DROP_TEMP_TABLE '#REGISTRY'
GO
