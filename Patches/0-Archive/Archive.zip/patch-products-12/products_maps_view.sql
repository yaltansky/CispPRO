﻿if object_id('products_maps_view') is not null drop proc products_maps_view
go
-- exec products_maps_view 1000
create proc products_maps_view
	@mol_id int,	
	-- filter
	@slice varchar(50),
	@search nvarchar(max) = null,
	-- sorting, paging
	@sort_expression varchar(50) = null,
	@offset int = 0,
	@fetchrows int = 30,
	--
	@rowscount int = null out
as
begin

    set nocount on;

	-- prepare sql
		declare @sql nvarchar(max), @fields nvarchar(max)

		declare @where nvarchar(max) = concat(
			' where (slice = @slice) '

			-- @search
			, case
				when @search is not null then 'and (x.name like @search or x.product_name like @search)'
			  end
			)

		declare @fields_base nvarchar(max) = N'
			@mol_id int,
			@slice varchar(50),
			@search nvarchar(max)
			'

		declare @join nvarchar(max) = N''

    -- @rowscount
        set @sql = N'select @rowscount = count(*) from V_PRODUCTS_MAPS x with(nolock) ' + @join + @where

        set @fields = @fields_base + ', @rowscount int out'

        exec sp_executesql @sql, @fields,
            @mol_id, @slice, @search,
            @rowscount out

        -- @order_by
        declare @order_by nvarchar(100) = N' order by x.name'
        if @sort_expression is not null set @order_by = N' order by ' + @sort_expression

			declare @subquery nvarchar(max) = N'(select x.* from V_PRODUCTS_MAPS x with(nolock) '
			+ @join + @where
			+ ' ) x ' + @order_by

    -- @sql
        set @sql = N'select x.* from ' + @subquery
        if @rowscount > @fetchrows set @sql = @sql + ' offset @offset rows fetch next @fetchrows rows only'

        set @fields = @fields_base + ', @offset int, @fetchrows int'

        exec sp_executesql @sql, @fields,
            @mol_id, @slice, @search,
            @offset, @fetchrows

end
go
